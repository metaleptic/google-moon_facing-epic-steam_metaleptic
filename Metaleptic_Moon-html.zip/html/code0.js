gdjs.LevelCode = {};
gdjs.LevelCode.GDBossBottomArmObjects2_1final = [];

gdjs.LevelCode.GDBossTopArmObjects2_1final = [];

gdjs.LevelCode.forEachCount0_3 = 0;

gdjs.LevelCode.forEachCount10_3 = 0;

gdjs.LevelCode.forEachCount11_3 = 0;

gdjs.LevelCode.forEachCount12_3 = 0;

gdjs.LevelCode.forEachCount13_3 = 0;

gdjs.LevelCode.forEachCount1_3 = 0;

gdjs.LevelCode.forEachCount2_3 = 0;

gdjs.LevelCode.forEachCount3_3 = 0;

gdjs.LevelCode.forEachCount4_3 = 0;

gdjs.LevelCode.forEachCount5_3 = 0;

gdjs.LevelCode.forEachCount6_3 = 0;

gdjs.LevelCode.forEachCount7_3 = 0;

gdjs.LevelCode.forEachCount8_3 = 0;

gdjs.LevelCode.forEachCount9_3 = 0;

gdjs.LevelCode.forEachIndex3 = 0;

gdjs.LevelCode.forEachObjects3 = [];

gdjs.LevelCode.forEachTotalCount3 = 0;

gdjs.LevelCode.repeatCount5 = 0;

gdjs.LevelCode.repeatIndex5 = 0;

gdjs.LevelCode.GDPlayerObjects1= [];
gdjs.LevelCode.GDPlayerObjects2= [];
gdjs.LevelCode.GDPlayerObjects3= [];
gdjs.LevelCode.GDPlayerObjects4= [];
gdjs.LevelCode.GDPlayerObjects5= [];
gdjs.LevelCode.GDPlayerObjects6= [];
gdjs.LevelCode.GDSpaceBackgroundObjects1= [];
gdjs.LevelCode.GDSpaceBackgroundObjects2= [];
gdjs.LevelCode.GDSpaceBackgroundObjects3= [];
gdjs.LevelCode.GDSpaceBackgroundObjects4= [];
gdjs.LevelCode.GDSpaceBackgroundObjects5= [];
gdjs.LevelCode.GDSpaceBackgroundObjects6= [];
gdjs.LevelCode.GDCorridorBackgroundObjects1= [];
gdjs.LevelCode.GDCorridorBackgroundObjects2= [];
gdjs.LevelCode.GDCorridorBackgroundObjects3= [];
gdjs.LevelCode.GDCorridorBackgroundObjects4= [];
gdjs.LevelCode.GDCorridorBackgroundObjects5= [];
gdjs.LevelCode.GDCorridorBackgroundObjects6= [];
gdjs.LevelCode.GDsalesObjects1= [];
gdjs.LevelCode.GDsalesObjects2= [];
gdjs.LevelCode.GDsalesObjects3= [];
gdjs.LevelCode.GDsalesObjects4= [];
gdjs.LevelCode.GDsalesObjects5= [];
gdjs.LevelCode.GDsalesObjects6= [];
gdjs.LevelCode.GDarrowObjects1= [];
gdjs.LevelCode.GDarrowObjects2= [];
gdjs.LevelCode.GDarrowObjects3= [];
gdjs.LevelCode.GDarrowObjects4= [];
gdjs.LevelCode.GDarrowObjects5= [];
gdjs.LevelCode.GDarrowObjects6= [];
gdjs.LevelCode.GDlambdafriendObjects1= [];
gdjs.LevelCode.GDlambdafriendObjects2= [];
gdjs.LevelCode.GDlambdafriendObjects3= [];
gdjs.LevelCode.GDlambdafriendObjects4= [];
gdjs.LevelCode.GDlambdafriendObjects5= [];
gdjs.LevelCode.GDlambdafriendObjects6= [];
gdjs.LevelCode.GDshootObjects1= [];
gdjs.LevelCode.GDshootObjects2= [];
gdjs.LevelCode.GDshootObjects3= [];
gdjs.LevelCode.GDshootObjects4= [];
gdjs.LevelCode.GDshootObjects5= [];
gdjs.LevelCode.GDshootObjects6= [];
gdjs.LevelCode.GDnotbrainObjects1= [];
gdjs.LevelCode.GDnotbrainObjects2= [];
gdjs.LevelCode.GDnotbrainObjects3= [];
gdjs.LevelCode.GDnotbrainObjects4= [];
gdjs.LevelCode.GDnotbrainObjects5= [];
gdjs.LevelCode.GDnotbrainObjects6= [];
gdjs.LevelCode.GDmelteye2Objects1= [];
gdjs.LevelCode.GDmelteye2Objects2= [];
gdjs.LevelCode.GDmelteye2Objects3= [];
gdjs.LevelCode.GDmelteye2Objects4= [];
gdjs.LevelCode.GDmelteye2Objects5= [];
gdjs.LevelCode.GDmelteye2Objects6= [];
gdjs.LevelCode.GDmelteye3Objects1= [];
gdjs.LevelCode.GDmelteye3Objects2= [];
gdjs.LevelCode.GDmelteye3Objects3= [];
gdjs.LevelCode.GDmelteye3Objects4= [];
gdjs.LevelCode.GDmelteye3Objects5= [];
gdjs.LevelCode.GDmelteye3Objects6= [];
gdjs.LevelCode.GDmelteye4Objects1= [];
gdjs.LevelCode.GDmelteye4Objects2= [];
gdjs.LevelCode.GDmelteye4Objects3= [];
gdjs.LevelCode.GDmelteye4Objects4= [];
gdjs.LevelCode.GDmelteye4Objects5= [];
gdjs.LevelCode.GDmelteye4Objects6= [];
gdjs.LevelCode.GDmelteyeObjects1= [];
gdjs.LevelCode.GDmelteyeObjects2= [];
gdjs.LevelCode.GDmelteyeObjects3= [];
gdjs.LevelCode.GDmelteyeObjects4= [];
gdjs.LevelCode.GDmelteyeObjects5= [];
gdjs.LevelCode.GDmelteyeObjects6= [];
gdjs.LevelCode.GDEnemy22Objects1= [];
gdjs.LevelCode.GDEnemy22Objects2= [];
gdjs.LevelCode.GDEnemy22Objects3= [];
gdjs.LevelCode.GDEnemy22Objects4= [];
gdjs.LevelCode.GDEnemy22Objects5= [];
gdjs.LevelCode.GDEnemy22Objects6= [];
gdjs.LevelCode.GDEnemy2Objects1= [];
gdjs.LevelCode.GDEnemy2Objects2= [];
gdjs.LevelCode.GDEnemy2Objects3= [];
gdjs.LevelCode.GDEnemy2Objects4= [];
gdjs.LevelCode.GDEnemy2Objects5= [];
gdjs.LevelCode.GDEnemy2Objects6= [];
gdjs.LevelCode.GDPlayerBulletObjects1= [];
gdjs.LevelCode.GDPlayerBulletObjects2= [];
gdjs.LevelCode.GDPlayerBulletObjects3= [];
gdjs.LevelCode.GDPlayerBulletObjects4= [];
gdjs.LevelCode.GDPlayerBulletObjects5= [];
gdjs.LevelCode.GDPlayerBulletObjects6= [];
gdjs.LevelCode.GDHealthPackObjects1= [];
gdjs.LevelCode.GDHealthPackObjects2= [];
gdjs.LevelCode.GDHealthPackObjects3= [];
gdjs.LevelCode.GDHealthPackObjects4= [];
gdjs.LevelCode.GDHealthPackObjects5= [];
gdjs.LevelCode.GDHealthPackObjects6= [];
gdjs.LevelCode.GDExplosionObjects1= [];
gdjs.LevelCode.GDExplosionObjects2= [];
gdjs.LevelCode.GDExplosionObjects3= [];
gdjs.LevelCode.GDExplosionObjects4= [];
gdjs.LevelCode.GDExplosionObjects5= [];
gdjs.LevelCode.GDExplosionObjects6= [];
gdjs.LevelCode.GDEnemy322Objects1= [];
gdjs.LevelCode.GDEnemy322Objects2= [];
gdjs.LevelCode.GDEnemy322Objects3= [];
gdjs.LevelCode.GDEnemy322Objects4= [];
gdjs.LevelCode.GDEnemy322Objects5= [];
gdjs.LevelCode.GDEnemy322Objects6= [];
gdjs.LevelCode.GDEnemy32Objects1= [];
gdjs.LevelCode.GDEnemy32Objects2= [];
gdjs.LevelCode.GDEnemy32Objects3= [];
gdjs.LevelCode.GDEnemy32Objects4= [];
gdjs.LevelCode.GDEnemy32Objects5= [];
gdjs.LevelCode.GDEnemy32Objects6= [];
gdjs.LevelCode.GDEnemy34Objects1= [];
gdjs.LevelCode.GDEnemy34Objects2= [];
gdjs.LevelCode.GDEnemy34Objects3= [];
gdjs.LevelCode.GDEnemy34Objects4= [];
gdjs.LevelCode.GDEnemy34Objects5= [];
gdjs.LevelCode.GDEnemy34Objects6= [];
gdjs.LevelCode.GDEnemy33Objects1= [];
gdjs.LevelCode.GDEnemy33Objects2= [];
gdjs.LevelCode.GDEnemy33Objects3= [];
gdjs.LevelCode.GDEnemy33Objects4= [];
gdjs.LevelCode.GDEnemy33Objects5= [];
gdjs.LevelCode.GDEnemy33Objects6= [];
gdjs.LevelCode.GDEnemy3Objects1= [];
gdjs.LevelCode.GDEnemy3Objects2= [];
gdjs.LevelCode.GDEnemy3Objects3= [];
gdjs.LevelCode.GDEnemy3Objects4= [];
gdjs.LevelCode.GDEnemy3Objects5= [];
gdjs.LevelCode.GDEnemy3Objects6= [];
gdjs.LevelCode.GDEnemyBullet2Objects1= [];
gdjs.LevelCode.GDEnemyBullet2Objects2= [];
gdjs.LevelCode.GDEnemyBullet2Objects3= [];
gdjs.LevelCode.GDEnemyBullet2Objects4= [];
gdjs.LevelCode.GDEnemyBullet2Objects5= [];
gdjs.LevelCode.GDEnemyBullet2Objects6= [];
gdjs.LevelCode.GDEnemyBulletObjects1= [];
gdjs.LevelCode.GDEnemyBulletObjects2= [];
gdjs.LevelCode.GDEnemyBulletObjects3= [];
gdjs.LevelCode.GDEnemyBulletObjects4= [];
gdjs.LevelCode.GDEnemyBulletObjects5= [];
gdjs.LevelCode.GDEnemyBulletObjects6= [];
gdjs.LevelCode.GDEnemy1Objects1= [];
gdjs.LevelCode.GDEnemy1Objects2= [];
gdjs.LevelCode.GDEnemy1Objects3= [];
gdjs.LevelCode.GDEnemy1Objects4= [];
gdjs.LevelCode.GDEnemy1Objects5= [];
gdjs.LevelCode.GDEnemy1Objects6= [];
gdjs.LevelCode.GDAttackFlameObjects1= [];
gdjs.LevelCode.GDAttackFlameObjects2= [];
gdjs.LevelCode.GDAttackFlameObjects3= [];
gdjs.LevelCode.GDAttackFlameObjects4= [];
gdjs.LevelCode.GDAttackFlameObjects5= [];
gdjs.LevelCode.GDAttackFlameObjects6= [];
gdjs.LevelCode.GDLifebarContainerObjects1= [];
gdjs.LevelCode.GDLifebarContainerObjects2= [];
gdjs.LevelCode.GDLifebarContainerObjects3= [];
gdjs.LevelCode.GDLifebarContainerObjects4= [];
gdjs.LevelCode.GDLifebarContainerObjects5= [];
gdjs.LevelCode.GDLifebarContainerObjects6= [];
gdjs.LevelCode.GDLifebarObjects1= [];
gdjs.LevelCode.GDLifebarObjects2= [];
gdjs.LevelCode.GDLifebarObjects3= [];
gdjs.LevelCode.GDLifebarObjects4= [];
gdjs.LevelCode.GDLifebarObjects5= [];
gdjs.LevelCode.GDLifebarObjects6= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects1= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects2= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects3= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects4= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects5= [];
gdjs.LevelCode.GDPlayerAttackAreaObjects6= [];
gdjs.LevelCode.GDChangeButtonObjects1= [];
gdjs.LevelCode.GDChangeButtonObjects2= [];
gdjs.LevelCode.GDChangeButtonObjects3= [];
gdjs.LevelCode.GDChangeButtonObjects4= [];
gdjs.LevelCode.GDChangeButtonObjects5= [];
gdjs.LevelCode.GDChangeButtonObjects6= [];
gdjs.LevelCode.GDBossBodyObjects1= [];
gdjs.LevelCode.GDBossBodyObjects2= [];
gdjs.LevelCode.GDBossBodyObjects3= [];
gdjs.LevelCode.GDBossBodyObjects4= [];
gdjs.LevelCode.GDBossBodyObjects5= [];
gdjs.LevelCode.GDBossBodyObjects6= [];
gdjs.LevelCode.GDBossTopArmObjects1= [];
gdjs.LevelCode.GDBossTopArmObjects2= [];
gdjs.LevelCode.GDBossTopArmObjects3= [];
gdjs.LevelCode.GDBossTopArmObjects4= [];
gdjs.LevelCode.GDBossTopArmObjects5= [];
gdjs.LevelCode.GDBossTopArmObjects6= [];
gdjs.LevelCode.GDBossBottomArmObjects1= [];
gdjs.LevelCode.GDBossBottomArmObjects2= [];
gdjs.LevelCode.GDBossBottomArmObjects3= [];
gdjs.LevelCode.GDBossBottomArmObjects4= [];
gdjs.LevelCode.GDBossBottomArmObjects5= [];
gdjs.LevelCode.GDBossBottomArmObjects6= [];
gdjs.LevelCode.GDBossSuperLaserObjects1= [];
gdjs.LevelCode.GDBossSuperLaserObjects2= [];
gdjs.LevelCode.GDBossSuperLaserObjects3= [];
gdjs.LevelCode.GDBossSuperLaserObjects4= [];
gdjs.LevelCode.GDBossSuperLaserObjects5= [];
gdjs.LevelCode.GDBossSuperLaserObjects6= [];
gdjs.LevelCode.GDBossBackgroundObjects1= [];
gdjs.LevelCode.GDBossBackgroundObjects2= [];
gdjs.LevelCode.GDBossBackgroundObjects3= [];
gdjs.LevelCode.GDBossBackgroundObjects4= [];
gdjs.LevelCode.GDBossBackgroundObjects5= [];
gdjs.LevelCode.GDBossBackgroundObjects6= [];
gdjs.LevelCode.GDFadeObjects1= [];
gdjs.LevelCode.GDFadeObjects2= [];
gdjs.LevelCode.GDFadeObjects3= [];
gdjs.LevelCode.GDFadeObjects4= [];
gdjs.LevelCode.GDFadeObjects5= [];
gdjs.LevelCode.GDFadeObjects6= [];
gdjs.LevelCode.GDGameOverObjects1= [];
gdjs.LevelCode.GDGameOverObjects2= [];
gdjs.LevelCode.GDGameOverObjects3= [];
gdjs.LevelCode.GDGameOverObjects4= [];
gdjs.LevelCode.GDGameOverObjects5= [];
gdjs.LevelCode.GDGameOverObjects6= [];
gdjs.LevelCode.GDDISPLAY_95SCOREObjects1= [];
gdjs.LevelCode.GDDISPLAY_95SCOREObjects2= [];
gdjs.LevelCode.GDDISPLAY_95SCOREObjects3= [];
gdjs.LevelCode.GDDISPLAY_95SCOREObjects4= [];
gdjs.LevelCode.GDDISPLAY_95SCOREObjects5= [];
gdjs.LevelCode.GDDISPLAY_95SCOREObjects6= [];
gdjs.LevelCode.GDrevenueObjects1= [];
gdjs.LevelCode.GDrevenueObjects2= [];
gdjs.LevelCode.GDrevenueObjects3= [];
gdjs.LevelCode.GDrevenueObjects4= [];
gdjs.LevelCode.GDrevenueObjects5= [];
gdjs.LevelCode.GDrevenueObjects6= [];
gdjs.LevelCode.GDspaceObjects1= [];
gdjs.LevelCode.GDspaceObjects2= [];
gdjs.LevelCode.GDspaceObjects3= [];
gdjs.LevelCode.GDspaceObjects4= [];
gdjs.LevelCode.GDspaceObjects5= [];
gdjs.LevelCode.GDspaceObjects6= [];
gdjs.LevelCode.GDlogosObjects1= [];
gdjs.LevelCode.GDlogosObjects2= [];
gdjs.LevelCode.GDlogosObjects3= [];
gdjs.LevelCode.GDlogosObjects4= [];
gdjs.LevelCode.GDlogosObjects5= [];
gdjs.LevelCode.GDlogosObjects6= [];
gdjs.LevelCode.GDselllllsObjects1= [];
gdjs.LevelCode.GDselllllsObjects2= [];
gdjs.LevelCode.GDselllllsObjects3= [];
gdjs.LevelCode.GDselllllsObjects4= [];
gdjs.LevelCode.GDselllllsObjects5= [];
gdjs.LevelCode.GDselllllsObjects6= [];

gdjs.LevelCode.conditionTrue_0 = {val:false};
gdjs.LevelCode.condition0IsTrue_0 = {val:false};
gdjs.LevelCode.condition1IsTrue_0 = {val:false};
gdjs.LevelCode.condition2IsTrue_0 = {val:false};
gdjs.LevelCode.condition3IsTrue_0 = {val:false};
gdjs.LevelCode.condition4IsTrue_0 = {val:false};
gdjs.LevelCode.conditionTrue_1 = {val:false};
gdjs.LevelCode.condition0IsTrue_1 = {val:false};
gdjs.LevelCode.condition1IsTrue_1 = {val:false};
gdjs.LevelCode.condition2IsTrue_1 = {val:false};
gdjs.LevelCode.condition3IsTrue_1 = {val:false};
gdjs.LevelCode.condition4IsTrue_1 = {val:false};


gdjs.LevelCode.eventsList0 = function(runtimeScene) {

{


{
{gdjs.evtTools.sound.playMusic(runtimeScene, "5-Bagavnu.ogg", true, 70, 1);
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects = Hashtable.newFrom({"ChangeButton": gdjs.LevelCode.GDChangeButtonObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects4Objects = Hashtable.newFrom({"PlayerBullet": gdjs.LevelCode.GDPlayerBulletObjects4});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects4});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects4});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});gdjs.LevelCode.eventsList1 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__ShouldFire.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDAttackFlameObjects2, gdjs.LevelCode.GDAttackFlameObjects4);

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.LevelCode.GDPlayerBulletObjects4);
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDPlayerObjects4[i].getPointX("Bullets")), (gdjs.LevelCode.GDPlayerObjects4[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects4Objects, 0, 310, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LevelCode.GDAttackFlameObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDAttackFlameObjects4[i].hide(false);
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects4[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects4[k] = gdjs.LevelCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects4.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "oh.ogg", false, 30, 1);
}}

}


{


{
gdjs.copyArray(gdjs.LevelCode.GDAttackFlameObjects2, gdjs.LevelCode.GDAttackFlameObjects4);

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);

{for(var i = 0, len = gdjs.LevelCode.GDAttackFlameObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDAttackFlameObjects4[i].setPosition((( gdjs.LevelCode.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects4[0].getPointX("Bullets")),(( gdjs.LevelCode.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects4[0].getPointY("Bullets")));
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__GoingUp.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("SpaceshipUp");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__GoingDown.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("SpaceshipDown");
}
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects3 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = !(gdjs.evtsExt__SpaceShooterControls__GoingDown.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = !(gdjs.evtsExt__SpaceShooterControls__GoingUp.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects3[i].setAnimationName("SpaceshipIdle");
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects = Hashtable.newFrom({"ChangeButton": gdjs.LevelCode.GDChangeButtonObjects2});gdjs.LevelCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects2, gdjs.LevelCode.GDPlayerObjects3);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayerObjects3[i].isCurrentAnimationName("SpaceshipToMech")) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ChangeButton"), gdjs.LevelCode.GDChangeButtonObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__ShouldTransform.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].setAnimationName("SpaceshipToMech");
}
}}

}


};gdjs.LevelCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects4, gdjs.LevelCode.GDPlayerObjects5);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects5.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects5[i].getAnimationFrame() > 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects5[k] = gdjs.LevelCode.GDPlayerObjects5[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects5.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects5 */
gdjs.copyArray(gdjs.LevelCode.GDPlayerAttackAreaObjects2, gdjs.LevelCode.GDPlayerAttackAreaObjects5);

{for(var i = 0, len = gdjs.LevelCode.GDPlayerAttackAreaObjects5.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerAttackAreaObjects5[i].setPosition((( gdjs.LevelCode.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects5[0].getPointX("")),(( gdjs.LevelCode.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects5[0].getPointY("")));
}
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects4 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects4[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects4[k] = gdjs.LevelCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects4.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("MechIdle");
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects4});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects4});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects3});gdjs.LevelCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__GoingUp.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("MechUp");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__GoingDown.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("MechDown");
}
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects3 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = !(gdjs.evtsExt__SpaceShooterControls__GoingDown.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = !(gdjs.evtsExt__SpaceShooterControls__GoingUp.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects3[i].setAnimationName("MechIdle");
}
}}

}


};gdjs.LevelCode.eventsList5 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__ShouldFire.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);

{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects4[i].setAnimationName("MechAttack");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects3, gdjs.LevelCode.GDPlayerObjects4);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects4[i].isCurrentAnimationName("MechAttack") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects4[k] = gdjs.LevelCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects4.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects3 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayerObjects3[i].isCurrentAnimationName("MechAttack")) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects = Hashtable.newFrom({"ChangeButton": gdjs.LevelCode.GDChangeButtonObjects2});gdjs.LevelCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects2, gdjs.LevelCode.GDPlayerObjects3);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayerObjects3[i].isCurrentAnimationName("MechToSpaceship")) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ChangeButton"), gdjs.LevelCode.GDChangeButtonObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtsExt__SpaceShooterControls__ShouldTransform.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].setAnimationName("MechToSpaceship");
}
}}

}


};gdjs.LevelCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects2, gdjs.LevelCode.GDPlayerObjects3);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects3[i].isCurrentAnimationName("SpaceshipToMech") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects3[k] = gdjs.LevelCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects3.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects3[i].setAnimationName("MechIdle");
}
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects3[i].returnVariable(gdjs.LevelCode.GDPlayerObjects3[i].getVariables().getFromIndex(0)).setString("Mech");
}
}}

}


{

/* Reuse gdjs.LevelCode.GDPlayerObjects2 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].isCurrentAnimationName("MechToSpaceship") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].setAnimationName("SpaceshipIdle");
}
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].returnVariable(gdjs.LevelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)).setString("Spaceship");
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossSuperLaserObjects2Objects = Hashtable.newFrom({"BossSuperLaser": gdjs.LevelCode.GDBossSuperLaserObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});gdjs.LevelCode.eventsList8 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11433212);
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects1, gdjs.LevelCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].resetTimer("DeathExplosions");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDPlayerObjects1, gdjs.LevelCode.GDPlayerObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].timerElapsedTime("DeathExplosions", 0.08) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects2[0].getPointX("")) + gdjs.random(20), (( gdjs.LevelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects2[0].getPointY("")) + gdjs.random((( gdjs.LevelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects2[0].getHeight())), "");
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].resetTimer("DeathExplosions");
}
}}

}


{


{
}

}


};gdjs.LevelCode.eventsList9 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerAttackArea"), gdjs.LevelCode.GDPlayerAttackAreaObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDPlayerAttackAreaObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerAttackAreaObjects2[i].hide();
}
}
{ //Subevents
gdjs.LevelCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) != 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ChangeButton"), gdjs.LevelCode.GDChangeButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);
{gdjs.evtsExt__SpaceShooterControls__HandlePlayerMovement.func(runtimeScene, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects, "TopDownMovement", gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDChangeButtonObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].getVariableString(gdjs.LevelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == "Spaceship" ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AttackFlame"), gdjs.LevelCode.GDAttackFlameObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDAttackFlameObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDAttackFlameObjects2[i].hide();
}
}
{ //Subevents
gdjs.LevelCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].getVariableString(gdjs.LevelCode.GDPlayerObjects2[i].getVariables().getFromIndex(0)) == "Mech" ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayerAttackArea"), gdjs.LevelCode.GDPlayerAttackAreaObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDPlayerAttackAreaObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerAttackAreaObjects2[i].setPosition(0,0);
}
}
{ //Subevents
gdjs.LevelCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BossSuperLaser"), gdjs.LevelCode.GDBossSuperLaserObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossSuperLaserObjects2Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Health").Hit(40, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.LevelCode.GDEnemyBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDEnemyBulletObjects2 */
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDEnemyBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemyBulletObjects2[0].getPointX("")) + 5, (( gdjs.LevelCode.GDEnemyBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemyBulletObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.LevelCode.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemyBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Flash").Flash(0.8, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ouch.ogg", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Flash").IsFlashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__VibratingCamera__VibrateCameraAroundPosition.func(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2, 0, 1, 60, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Flash").IsFlashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects2[k] = gdjs.LevelCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2, "", 0);
}}

}


{



}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpaceBackground"), gdjs.LevelCode.GDSpaceBackgroundObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + (20 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)), "", 0);
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].addForce(20, 0, 0);
}
}{for(var i = 0, len = gdjs.LevelCode.GDSpaceBackgroundObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDSpaceBackgroundObjects2[i].setXOffset(gdjs.LevelCode.GDSpaceBackgroundObjects2[i].getXOffset() + (10 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDPlayerObjects1[k] = gdjs.LevelCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDPlayerObjects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).setNumber(1);
}
{ //Subevents
gdjs.LevelCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBullet2Objects2Objects = Hashtable.newFrom({"EnemyBullet2": gdjs.LevelCode.GDEnemyBullet2Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBullet2Objects2Objects = Hashtable.newFrom({"EnemyBullet2": gdjs.LevelCode.GDEnemyBullet2Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDmelteyeObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2ObjectsGDgdjs_46LevelCode_46GDnotbrainObjects2ObjectsGDgdjs_46LevelCode_46GDmelteye3Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye2Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy22Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy34Objects2ObjectsGDgdjs_46LevelCode_46GDshootObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy33Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye4Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy322Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy32Objects2Objects = Hashtable.newFrom({"Enemy2": gdjs.LevelCode.GDEnemy2Objects2, "melteye": gdjs.LevelCode.GDmelteyeObjects2, "Enemy3": gdjs.LevelCode.GDEnemy3Objects2, "Enemy1": gdjs.LevelCode.GDEnemy1Objects2, "notbrain": gdjs.LevelCode.GDnotbrainObjects2, "melteye3": gdjs.LevelCode.GDmelteye3Objects2, "melteye2": gdjs.LevelCode.GDmelteye2Objects2, "Enemy22": gdjs.LevelCode.GDEnemy22Objects2, "Enemy34": gdjs.LevelCode.GDEnemy34Objects2, "shoot": gdjs.LevelCode.GDshootObjects2, "Enemy33": gdjs.LevelCode.GDEnemy33Objects2, "melteye4": gdjs.LevelCode.GDmelteye4Objects2, "Enemy322": gdjs.LevelCode.GDEnemy322Objects2, "Enemy32": gdjs.LevelCode.GDEnemy32Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBullet2Objects2Objects = Hashtable.newFrom({"EnemyBullet2": gdjs.LevelCode.GDEnemyBullet2Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDmelteyeObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2ObjectsGDgdjs_46LevelCode_46GDnotbrainObjects2ObjectsGDgdjs_46LevelCode_46GDmelteye3Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye2Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy22Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy34Objects2ObjectsGDgdjs_46LevelCode_46GDshootObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy33Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye4Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy322Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy32Objects2Objects = Hashtable.newFrom({"Enemy2": gdjs.LevelCode.GDEnemy2Objects2, "melteye": gdjs.LevelCode.GDmelteyeObjects2, "Enemy3": gdjs.LevelCode.GDEnemy3Objects2, "Enemy1": gdjs.LevelCode.GDEnemy1Objects2, "notbrain": gdjs.LevelCode.GDnotbrainObjects2, "melteye3": gdjs.LevelCode.GDmelteye3Objects2, "melteye2": gdjs.LevelCode.GDmelteye2Objects2, "Enemy22": gdjs.LevelCode.GDEnemy22Objects2, "Enemy34": gdjs.LevelCode.GDEnemy34Objects2, "shoot": gdjs.LevelCode.GDshootObjects2, "Enemy33": gdjs.LevelCode.GDEnemy33Objects2, "melteye4": gdjs.LevelCode.GDmelteye4Objects2, "Enemy322": gdjs.LevelCode.GDEnemy322Objects2, "Enemy32": gdjs.LevelCode.GDEnemy32Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects = Hashtable.newFrom({"PlayerBullet": gdjs.LevelCode.GDPlayerBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy322Objects2Objects = Hashtable.newFrom({"Enemy322": gdjs.LevelCode.GDEnemy322Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects = Hashtable.newFrom({"PlayerBullet": gdjs.LevelCode.GDPlayerBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy32Objects2Objects = Hashtable.newFrom({"Enemy32": gdjs.LevelCode.GDEnemy32Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects = Hashtable.newFrom({"PlayerBullet": gdjs.LevelCode.GDPlayerBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDmelteyeObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2ObjectsGDgdjs_46LevelCode_46GDnotbrainObjects2ObjectsGDgdjs_46LevelCode_46GDmelteye3Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye2Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy22Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy34Objects2ObjectsGDgdjs_46LevelCode_46GDshootObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy33Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye4Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy322Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy32Objects2Objects = Hashtable.newFrom({"Enemy2": gdjs.LevelCode.GDEnemy2Objects2, "melteye": gdjs.LevelCode.GDmelteyeObjects2, "Enemy3": gdjs.LevelCode.GDEnemy3Objects2, "Enemy1": gdjs.LevelCode.GDEnemy1Objects2, "notbrain": gdjs.LevelCode.GDnotbrainObjects2, "melteye3": gdjs.LevelCode.GDmelteye3Objects2, "melteye2": gdjs.LevelCode.GDmelteye2Objects2, "Enemy22": gdjs.LevelCode.GDEnemy22Objects2, "Enemy34": gdjs.LevelCode.GDEnemy34Objects2, "shoot": gdjs.LevelCode.GDshootObjects2, "Enemy33": gdjs.LevelCode.GDEnemy33Objects2, "melteye4": gdjs.LevelCode.GDmelteye4Objects2, "Enemy322": gdjs.LevelCode.GDEnemy322Objects2, "Enemy32": gdjs.LevelCode.GDEnemy32Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects = Hashtable.newFrom({"PlayerAttackArea": gdjs.LevelCode.GDPlayerAttackAreaObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy322Objects2Objects = Hashtable.newFrom({"Enemy322": gdjs.LevelCode.GDEnemy322Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects = Hashtable.newFrom({"PlayerAttackArea": gdjs.LevelCode.GDPlayerAttackAreaObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy32Objects2Objects = Hashtable.newFrom({"Enemy32": gdjs.LevelCode.GDEnemy32Objects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects = Hashtable.newFrom({"PlayerAttackArea": gdjs.LevelCode.GDPlayerAttackAreaObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects5Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects5});gdjs.LevelCode.eventsList10 = function(runtimeScene) {

};gdjs.LevelCode.eventsList11 = function(runtimeScene) {

{


gdjs.LevelCode.repeatCount5 = 3;
for(gdjs.LevelCode.repeatIndex5 = 0;gdjs.LevelCode.repeatIndex5 < gdjs.LevelCode.repeatCount5;++gdjs.LevelCode.repeatIndex5) {
gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects3, gdjs.LevelCode.GDEnemy1Objects5);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects3, gdjs.LevelCode.GDEnemy2Objects5);

gdjs.copyArray(gdjs.LevelCode.GDEnemy22Objects3, gdjs.LevelCode.GDEnemy22Objects5);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects3, gdjs.LevelCode.GDEnemy3Objects5);

gdjs.copyArray(gdjs.LevelCode.GDEnemy32Objects3, gdjs.LevelCode.GDEnemy32Objects5);

gdjs.copyArray(gdjs.LevelCode.GDEnemy322Objects3, gdjs.LevelCode.GDEnemy322Objects5);

gdjs.copyArray(gdjs.LevelCode.GDEnemy33Objects3, gdjs.LevelCode.GDEnemy33Objects5);

gdjs.copyArray(gdjs.LevelCode.GDEnemy34Objects3, gdjs.LevelCode.GDEnemy34Objects5);

gdjs.copyArray(gdjs.LevelCode.GDmelteyeObjects3, gdjs.LevelCode.GDmelteyeObjects5);

gdjs.copyArray(gdjs.LevelCode.GDmelteye2Objects3, gdjs.LevelCode.GDmelteye2Objects5);

gdjs.copyArray(gdjs.LevelCode.GDmelteye3Objects3, gdjs.LevelCode.GDmelteye3Objects5);

gdjs.copyArray(gdjs.LevelCode.GDmelteye4Objects3, gdjs.LevelCode.GDmelteye4Objects5);

gdjs.copyArray(gdjs.LevelCode.GDnotbrainObjects3, gdjs.LevelCode.GDnotbrainObjects5);

gdjs.copyArray(gdjs.LevelCode.GDshootObjects3, gdjs.LevelCode.GDshootObjects5);

gdjs.LevelCode.GDExplosionObjects5.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects5Objects, (( gdjs.LevelCode.GDEnemy32Objects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy322Objects5.length === 0 ) ? (( gdjs.LevelCode.GDmelteye4Objects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy33Objects5.length === 0 ) ? (( gdjs.LevelCode.GDshootObjects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy34Objects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy22Objects5.length === 0 ) ? (( gdjs.LevelCode.GDmelteye2Objects5.length === 0 ) ? (( gdjs.LevelCode.GDmelteye3Objects5.length === 0 ) ? (( gdjs.LevelCode.GDnotbrainObjects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy1Objects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects5.length === 0 ) ? (( gdjs.LevelCode.GDmelteyeObjects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects5.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects5[0].getPointX("")) :gdjs.LevelCode.GDmelteyeObjects5[0].getPointX("")) :gdjs.LevelCode.GDEnemy3Objects5[0].getPointX("")) :gdjs.LevelCode.GDEnemy1Objects5[0].getPointX("")) :gdjs.LevelCode.GDnotbrainObjects5[0].getPointX("")) :gdjs.LevelCode.GDmelteye3Objects5[0].getPointX("")) :gdjs.LevelCode.GDmelteye2Objects5[0].getPointX("")) :gdjs.LevelCode.GDEnemy22Objects5[0].getPointX("")) :gdjs.LevelCode.GDEnemy34Objects5[0].getPointX("")) :gdjs.LevelCode.GDshootObjects5[0].getPointX("")) :gdjs.LevelCode.GDEnemy33Objects5[0].getPointX("")) :gdjs.LevelCode.GDmelteye4Objects5[0].getPointX("")) :gdjs.LevelCode.GDEnemy322Objects5[0].getPointX("")) :gdjs.LevelCode.GDEnemy32Objects5[0].getPointX("")) + gdjs.randomInRange(-(10), 10), (( gdjs.LevelCode.GDEnemy32Objects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy322Objects5.length === 0 ) ? (( gdjs.LevelCode.GDmelteye4Objects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy33Objects5.length === 0 ) ? (( gdjs.LevelCode.GDshootObjects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy34Objects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy22Objects5.length === 0 ) ? (( gdjs.LevelCode.GDmelteye2Objects5.length === 0 ) ? (( gdjs.LevelCode.GDmelteye3Objects5.length === 0 ) ? (( gdjs.LevelCode.GDnotbrainObjects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy1Objects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects5.length === 0 ) ? (( gdjs.LevelCode.GDmelteyeObjects5.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects5.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects5[0].getPointY("")) :gdjs.LevelCode.GDmelteyeObjects5[0].getPointY("")) :gdjs.LevelCode.GDEnemy3Objects5[0].getPointY("")) :gdjs.LevelCode.GDEnemy1Objects5[0].getPointY("")) :gdjs.LevelCode.GDnotbrainObjects5[0].getPointY("")) :gdjs.LevelCode.GDmelteye3Objects5[0].getPointY("")) :gdjs.LevelCode.GDmelteye2Objects5[0].getPointY("")) :gdjs.LevelCode.GDEnemy22Objects5[0].getPointY("")) :gdjs.LevelCode.GDEnemy34Objects5[0].getPointY("")) :gdjs.LevelCode.GDshootObjects5[0].getPointY("")) :gdjs.LevelCode.GDEnemy33Objects5[0].getPointY("")) :gdjs.LevelCode.GDmelteye4Objects5[0].getPointY("")) :gdjs.LevelCode.GDEnemy322Objects5[0].getPointY("")) :gdjs.LevelCode.GDEnemy32Objects5[0].getPointY("")) + gdjs.randomInRange(-(10), 10), "");
}}
}

}


};gdjs.LevelCode.eventsList12 = function(runtimeScene) {

{

/* Reuse gdjs.LevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy22Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy32Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy322Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy33Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy34Objects2 */
/* Reuse gdjs.LevelCode.GDmelteyeObjects2 */
/* Reuse gdjs.LevelCode.GDmelteye2Objects2 */
/* Reuse gdjs.LevelCode.GDmelteye3Objects2 */
/* Reuse gdjs.LevelCode.GDmelteye4Objects2 */
/* Reuse gdjs.LevelCode.GDnotbrainObjects2 */
/* Reuse gdjs.LevelCode.GDshootObjects2 */

gdjs.LevelCode.forEachTotalCount3 = 0;
gdjs.LevelCode.forEachObjects3.length = 0;
gdjs.LevelCode.forEachCount0_3 = gdjs.LevelCode.GDEnemy2Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount0_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy2Objects2);
gdjs.LevelCode.forEachCount1_3 = gdjs.LevelCode.GDmelteyeObjects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount1_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDmelteyeObjects2);
gdjs.LevelCode.forEachCount2_3 = gdjs.LevelCode.GDEnemy3Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount2_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy3Objects2);
gdjs.LevelCode.forEachCount3_3 = gdjs.LevelCode.GDEnemy1Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount3_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy1Objects2);
gdjs.LevelCode.forEachCount4_3 = gdjs.LevelCode.GDnotbrainObjects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount4_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDnotbrainObjects2);
gdjs.LevelCode.forEachCount5_3 = gdjs.LevelCode.GDmelteye3Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount5_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDmelteye3Objects2);
gdjs.LevelCode.forEachCount6_3 = gdjs.LevelCode.GDmelteye2Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount6_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDmelteye2Objects2);
gdjs.LevelCode.forEachCount7_3 = gdjs.LevelCode.GDEnemy22Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount7_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy22Objects2);
gdjs.LevelCode.forEachCount8_3 = gdjs.LevelCode.GDEnemy34Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount8_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy34Objects2);
gdjs.LevelCode.forEachCount9_3 = gdjs.LevelCode.GDshootObjects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount9_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDshootObjects2);
gdjs.LevelCode.forEachCount10_3 = gdjs.LevelCode.GDEnemy33Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount10_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy33Objects2);
gdjs.LevelCode.forEachCount11_3 = gdjs.LevelCode.GDmelteye4Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount11_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDmelteye4Objects2);
gdjs.LevelCode.forEachCount12_3 = gdjs.LevelCode.GDEnemy322Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount12_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy322Objects2);
gdjs.LevelCode.forEachCount13_3 = gdjs.LevelCode.GDEnemy32Objects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount13_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDEnemy32Objects2);
for(gdjs.LevelCode.forEachIndex3 = 0;gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachTotalCount3;++gdjs.LevelCode.forEachIndex3) {
gdjs.LevelCode.GDEnemy1Objects3.length = 0;

gdjs.LevelCode.GDEnemy2Objects3.length = 0;

gdjs.LevelCode.GDEnemy22Objects3.length = 0;

gdjs.LevelCode.GDEnemy3Objects3.length = 0;

gdjs.LevelCode.GDEnemy32Objects3.length = 0;

gdjs.LevelCode.GDEnemy322Objects3.length = 0;

gdjs.LevelCode.GDEnemy33Objects3.length = 0;

gdjs.LevelCode.GDEnemy34Objects3.length = 0;

gdjs.LevelCode.GDmelteyeObjects3.length = 0;

gdjs.LevelCode.GDmelteye2Objects3.length = 0;

gdjs.LevelCode.GDmelteye3Objects3.length = 0;

gdjs.LevelCode.GDmelteye4Objects3.length = 0;

gdjs.LevelCode.GDnotbrainObjects3.length = 0;

gdjs.LevelCode.GDshootObjects3.length = 0;


if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3) {
    gdjs.LevelCode.GDEnemy2Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3) {
    gdjs.LevelCode.GDmelteyeObjects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3) {
    gdjs.LevelCode.GDEnemy3Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3) {
    gdjs.LevelCode.GDEnemy1Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3+gdjs.LevelCode.forEachCount4_3) {
    gdjs.LevelCode.GDnotbrainObjects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3+gdjs.LevelCode.forEachCount4_3+gdjs.LevelCode.forEachCount5_3) {
    gdjs.LevelCode.GDmelteye3Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3+gdjs.LevelCode.forEachCount4_3+gdjs.LevelCode.forEachCount5_3+gdjs.LevelCode.forEachCount6_3) {
    gdjs.LevelCode.GDmelteye2Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3+gdjs.LevelCode.forEachCount4_3+gdjs.LevelCode.forEachCount5_3+gdjs.LevelCode.forEachCount6_3+gdjs.LevelCode.forEachCount7_3) {
    gdjs.LevelCode.GDEnemy22Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3+gdjs.LevelCode.forEachCount4_3+gdjs.LevelCode.forEachCount5_3+gdjs.LevelCode.forEachCount6_3+gdjs.LevelCode.forEachCount7_3+gdjs.LevelCode.forEachCount8_3) {
    gdjs.LevelCode.GDEnemy34Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3+gdjs.LevelCode.forEachCount4_3+gdjs.LevelCode.forEachCount5_3+gdjs.LevelCode.forEachCount6_3+gdjs.LevelCode.forEachCount7_3+gdjs.LevelCode.forEachCount8_3+gdjs.LevelCode.forEachCount9_3) {
    gdjs.LevelCode.GDshootObjects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3+gdjs.LevelCode.forEachCount4_3+gdjs.LevelCode.forEachCount5_3+gdjs.LevelCode.forEachCount6_3+gdjs.LevelCode.forEachCount7_3+gdjs.LevelCode.forEachCount8_3+gdjs.LevelCode.forEachCount9_3+gdjs.LevelCode.forEachCount10_3) {
    gdjs.LevelCode.GDEnemy33Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3+gdjs.LevelCode.forEachCount4_3+gdjs.LevelCode.forEachCount5_3+gdjs.LevelCode.forEachCount6_3+gdjs.LevelCode.forEachCount7_3+gdjs.LevelCode.forEachCount8_3+gdjs.LevelCode.forEachCount9_3+gdjs.LevelCode.forEachCount10_3+gdjs.LevelCode.forEachCount11_3) {
    gdjs.LevelCode.GDmelteye4Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3+gdjs.LevelCode.forEachCount4_3+gdjs.LevelCode.forEachCount5_3+gdjs.LevelCode.forEachCount6_3+gdjs.LevelCode.forEachCount7_3+gdjs.LevelCode.forEachCount8_3+gdjs.LevelCode.forEachCount9_3+gdjs.LevelCode.forEachCount10_3+gdjs.LevelCode.forEachCount11_3+gdjs.LevelCode.forEachCount12_3) {
    gdjs.LevelCode.GDEnemy322Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3+gdjs.LevelCode.forEachCount2_3+gdjs.LevelCode.forEachCount3_3+gdjs.LevelCode.forEachCount4_3+gdjs.LevelCode.forEachCount5_3+gdjs.LevelCode.forEachCount6_3+gdjs.LevelCode.forEachCount7_3+gdjs.LevelCode.forEachCount8_3+gdjs.LevelCode.forEachCount9_3+gdjs.LevelCode.forEachCount10_3+gdjs.LevelCode.forEachCount11_3+gdjs.LevelCode.forEachCount12_3+gdjs.LevelCode.forEachCount13_3) {
    gdjs.LevelCode.GDEnemy32Objects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
if (true) {

{ //Subevents: 
gdjs.LevelCode.eventsList11(runtimeScene);} //Subevents end.
}
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});gdjs.LevelCode.eventsList13 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.LevelCode.GDEnemy22Objects1, gdjs.LevelCode.GDEnemy22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.LevelCode.GDEnemyBulletObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDEnemy3Objects2[i].getPointX("Bullets")), (gdjs.LevelCode.GDEnemy3Objects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{}}

}


{


{
gdjs.copyArray(gdjs.LevelCode.GDEnemy34Objects1, gdjs.LevelCode.GDEnemy34Objects2);

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.LevelCode.GDEnemyBulletObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDEnemy34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy34Objects2[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDEnemy34Objects2[i].getPointX("Bullets")), (gdjs.LevelCode.GDEnemy34Objects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


{
gdjs.copyArray(gdjs.LevelCode.GDEnemy32Objects1, gdjs.LevelCode.GDEnemy32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy322Objects1, gdjs.LevelCode.GDEnemy322Objects2);

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.LevelCode.GDEnemyBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet2"), gdjs.LevelCode.GDEnemyBullet2Objects2);
{for(var i = 0, len = gdjs.LevelCode.GDEnemy32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy32Objects2[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDEnemy32Objects2[i].getPointX("Bullets")), (gdjs.LevelCode.GDEnemy32Objects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBullet2Objects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy322Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy322Objects2[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDEnemy322Objects2[i].getPointX("Bullets")), (gdjs.LevelCode.GDEnemy322Objects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


{
gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy33Objects1, gdjs.LevelCode.GDEnemy33Objects2);

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.LevelCode.GDEnemyBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet2"), gdjs.LevelCode.GDEnemyBullet2Objects2);
gdjs.copyArray(gdjs.LevelCode.GDmelteye4Objects1, gdjs.LevelCode.GDmelteye4Objects2);

{for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].getBehavior("FireBullet").Fire((( gdjs.LevelCode.GDEnemy3Objects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy3Objects2[0].getPointX("Bullets")), (gdjs.LevelCode.GDEnemy33Objects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].getBehavior("FireBullet").Fire((( gdjs.LevelCode.GDEnemy3Objects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy3Objects2[0].getPointX("Bullets")), (gdjs.LevelCode.GDEnemy33Objects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{}}

}


{


{
gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects1, gdjs.LevelCode.GDEnemy1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects1, gdjs.LevelCode.GDEnemy2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy22Objects1, gdjs.LevelCode.GDEnemy22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy32Objects1, gdjs.LevelCode.GDEnemy32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy322Objects1, gdjs.LevelCode.GDEnemy322Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy33Objects1, gdjs.LevelCode.GDEnemy33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy34Objects1, gdjs.LevelCode.GDEnemy34Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteyeObjects1, gdjs.LevelCode.GDmelteyeObjects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye2Objects1, gdjs.LevelCode.GDmelteye2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye3Objects1, gdjs.LevelCode.GDmelteye3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye4Objects1, gdjs.LevelCode.GDmelteye4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDnotbrainObjects1, gdjs.LevelCode.GDnotbrainObjects2);

gdjs.copyArray(gdjs.LevelCode.GDshootObjects1, gdjs.LevelCode.GDshootObjects2);

{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteyeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteyeObjects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDnotbrainObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDnotbrainObjects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye3Objects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye2Objects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy22Objects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy34Objects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDshootObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDshootObjects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye4Objects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy322Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy322Objects2[i].activateBehavior("Health", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy32Objects2[i].activateBehavior("Health", true);
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteyeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteyeObjects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDnotbrainObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDnotbrainObjects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye3Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye2Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy22Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy34Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDshootObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDshootObjects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye4Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy322Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy322Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy32Objects2[i].activateBehavior("LinearMovement", true);
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].activateBehavior("LinearMovement", true);
}
}{for(var i = 0, len = gdjs.LevelCode.GDmelteye3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye3Objects2[i].activateBehavior("LinearMovement", true);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects1, gdjs.LevelCode.GDEnemy1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects1, gdjs.LevelCode.GDEnemy2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy22Objects1, gdjs.LevelCode.GDEnemy22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy32Objects1, gdjs.LevelCode.GDEnemy32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy322Objects1, gdjs.LevelCode.GDEnemy322Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy33Objects1, gdjs.LevelCode.GDEnemy33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy34Objects1, gdjs.LevelCode.GDEnemy34Objects2);

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);
gdjs.copyArray(gdjs.LevelCode.GDmelteyeObjects1, gdjs.LevelCode.GDmelteyeObjects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye2Objects1, gdjs.LevelCode.GDmelteye2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye3Objects1, gdjs.LevelCode.GDmelteye3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye4Objects1, gdjs.LevelCode.GDmelteye4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDnotbrainObjects1, gdjs.LevelCode.GDnotbrainObjects2);

gdjs.copyArray(gdjs.LevelCode.GDshootObjects1, gdjs.LevelCode.GDshootObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDmelteyeObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2ObjectsGDgdjs_46LevelCode_46GDnotbrainObjects2ObjectsGDgdjs_46LevelCode_46GDmelteye3Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye2Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy22Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy34Objects2ObjectsGDgdjs_46LevelCode_46GDshootObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy33Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye4Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy322Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy32Objects2Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy22Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy32Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy322Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy33Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy34Objects2 */
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
/* Reuse gdjs.LevelCode.GDmelteyeObjects2 */
/* Reuse gdjs.LevelCode.GDmelteye2Objects2 */
/* Reuse gdjs.LevelCode.GDmelteye3Objects2 */
/* Reuse gdjs.LevelCode.GDmelteye4Objects2 */
/* Reuse gdjs.LevelCode.GDnotbrainObjects2 */
/* Reuse gdjs.LevelCode.GDshootObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteyeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteyeObjects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDnotbrainObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDnotbrainObjects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye3Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye2Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy22Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy34Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDshootObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDshootObjects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye4Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy322Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy322Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy32Objects2[i].getBehavior("Health").Hit(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Health").Hit(12, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet2"), gdjs.LevelCode.GDEnemyBullet2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBullet2Objects2Objects, false, runtimeScene, true);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects2[i].getBehavior("Health").Hit(20, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects1, gdjs.LevelCode.GDEnemy1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects1, gdjs.LevelCode.GDEnemy2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy22Objects1, gdjs.LevelCode.GDEnemy22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy32Objects1, gdjs.LevelCode.GDEnemy32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy322Objects1, gdjs.LevelCode.GDEnemy322Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy33Objects1, gdjs.LevelCode.GDEnemy33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy34Objects1, gdjs.LevelCode.GDEnemy34Objects2);

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.LevelCode.GDPlayerBulletObjects2);
gdjs.copyArray(gdjs.LevelCode.GDmelteyeObjects1, gdjs.LevelCode.GDmelteyeObjects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye2Objects1, gdjs.LevelCode.GDmelteye2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye3Objects1, gdjs.LevelCode.GDmelteye3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye4Objects1, gdjs.LevelCode.GDmelteye4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDnotbrainObjects1, gdjs.LevelCode.GDnotbrainObjects2);

gdjs.copyArray(gdjs.LevelCode.GDshootObjects1, gdjs.LevelCode.GDshootObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDmelteyeObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2ObjectsGDgdjs_46LevelCode_46GDnotbrainObjects2ObjectsGDgdjs_46LevelCode_46GDmelteye3Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye2Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy22Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy34Objects2ObjectsGDgdjs_46LevelCode_46GDshootObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy33Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye4Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy322Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy32Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy22Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy32Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy322Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy33Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy34Objects2 */
/* Reuse gdjs.LevelCode.GDPlayerBulletObjects2 */
/* Reuse gdjs.LevelCode.GDmelteyeObjects2 */
/* Reuse gdjs.LevelCode.GDmelteye2Objects2 */
/* Reuse gdjs.LevelCode.GDmelteye3Objects2 */
/* Reuse gdjs.LevelCode.GDmelteye4Objects2 */
/* Reuse gdjs.LevelCode.GDnotbrainObjects2 */
/* Reuse gdjs.LevelCode.GDshootObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteyeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteyeObjects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDnotbrainObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDnotbrainObjects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye3Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye2Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy22Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy34Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDshootObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDshootObjects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye4Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy322Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy322Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy32Objects2[i].getBehavior("Health").Hit(7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointX("")) + 5, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDEnemy32Objects1, gdjs.LevelCode.GDEnemy32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy322Objects1, gdjs.LevelCode.GDEnemy322Objects2);

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.LevelCode.GDPlayerBulletObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy322Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects, false, runtimeScene, true);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy32Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects, false, runtimeScene, true);
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDEnemy322Objects2 */
/* Reuse gdjs.LevelCode.GDPlayerBulletObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDEnemy322Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy322Objects2[i].getBehavior("Health").Hit(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointX("")) + 5, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointY("")), "");
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects1, gdjs.LevelCode.GDEnemy1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects1, gdjs.LevelCode.GDEnemy2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy22Objects1, gdjs.LevelCode.GDEnemy22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy32Objects1, gdjs.LevelCode.GDEnemy32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy322Objects1, gdjs.LevelCode.GDEnemy322Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy33Objects1, gdjs.LevelCode.GDEnemy33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy34Objects1, gdjs.LevelCode.GDEnemy34Objects2);

gdjs.copyArray(runtimeScene.getObjects("PlayerAttackArea"), gdjs.LevelCode.GDPlayerAttackAreaObjects2);
gdjs.copyArray(gdjs.LevelCode.GDmelteyeObjects1, gdjs.LevelCode.GDmelteyeObjects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye2Objects1, gdjs.LevelCode.GDmelteye2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye3Objects1, gdjs.LevelCode.GDmelteye3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye4Objects1, gdjs.LevelCode.GDmelteye4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDnotbrainObjects1, gdjs.LevelCode.GDnotbrainObjects2);

gdjs.copyArray(gdjs.LevelCode.GDshootObjects1, gdjs.LevelCode.GDshootObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
gdjs.LevelCode.condition3IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46LevelCode_46GDmelteyeObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy1Objects2ObjectsGDgdjs_46LevelCode_46GDnotbrainObjects2ObjectsGDgdjs_46LevelCode_46GDmelteye3Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye2Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy22Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy34Objects2ObjectsGDgdjs_46LevelCode_46GDshootObjects2ObjectsGDgdjs_46LevelCode_46GDEnemy33Objects2ObjectsGDgdjs_46LevelCode_46GDmelteye4Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy322Objects2ObjectsGDgdjs_46LevelCode_46GDEnemy32Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy322Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects, false, runtimeScene, true);
}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
gdjs.LevelCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemy32Objects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects, false, runtimeScene, true);
}if ( gdjs.LevelCode.condition2IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition3IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11450188);
}
}}
}
}
if (gdjs.LevelCode.condition3IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy22Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy32Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy322Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy33Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy34Objects2 */
/* Reuse gdjs.LevelCode.GDmelteyeObjects2 */
/* Reuse gdjs.LevelCode.GDmelteye2Objects2 */
/* Reuse gdjs.LevelCode.GDmelteye3Objects2 */
/* Reuse gdjs.LevelCode.GDmelteye4Objects2 */
/* Reuse gdjs.LevelCode.GDnotbrainObjects2 */
/* Reuse gdjs.LevelCode.GDshootObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteyeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteyeObjects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDnotbrainObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDnotbrainObjects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye3Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye2Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy22Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy34Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDshootObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDshootObjects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye4Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy322Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy322Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy32Objects2[i].getBehavior("Health").Hit(30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.LevelCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelCode.GDEnemy1Objects1, gdjs.LevelCode.GDEnemy1Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy2Objects1, gdjs.LevelCode.GDEnemy2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy22Objects1, gdjs.LevelCode.GDEnemy22Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy3Objects1, gdjs.LevelCode.GDEnemy3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy32Objects1, gdjs.LevelCode.GDEnemy32Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy322Objects1, gdjs.LevelCode.GDEnemy322Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy33Objects1, gdjs.LevelCode.GDEnemy33Objects2);

gdjs.copyArray(gdjs.LevelCode.GDEnemy34Objects1, gdjs.LevelCode.GDEnemy34Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteyeObjects1, gdjs.LevelCode.GDmelteyeObjects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye2Objects1, gdjs.LevelCode.GDmelteye2Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye3Objects1, gdjs.LevelCode.GDmelteye3Objects2);

gdjs.copyArray(gdjs.LevelCode.GDmelteye4Objects1, gdjs.LevelCode.GDmelteye4Objects2);

gdjs.copyArray(gdjs.LevelCode.GDnotbrainObjects1, gdjs.LevelCode.GDnotbrainObjects2);

gdjs.copyArray(gdjs.LevelCode.GDshootObjects1, gdjs.LevelCode.GDshootObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy2Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy2Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy2Objects2[k] = gdjs.LevelCode.GDEnemy2Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteyeObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteyeObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteyeObjects2[k] = gdjs.LevelCode.GDmelteyeObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteyeObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy3Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy3Objects2[k] = gdjs.LevelCode.GDEnemy3Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy3Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy1Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy1Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy1Objects2[k] = gdjs.LevelCode.GDEnemy1Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDnotbrainObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDnotbrainObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDnotbrainObjects2[k] = gdjs.LevelCode.GDnotbrainObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDnotbrainObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye3Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye3Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye3Objects2[k] = gdjs.LevelCode.GDmelteye3Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye3Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye2Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye2Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye2Objects2[k] = gdjs.LevelCode.GDmelteye2Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy22Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy22Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy22Objects2[k] = gdjs.LevelCode.GDEnemy22Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy22Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy34Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy34Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy34Objects2[k] = gdjs.LevelCode.GDEnemy34Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy34Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDshootObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDshootObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDshootObjects2[k] = gdjs.LevelCode.GDshootObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDshootObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy33Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy33Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy33Objects2[k] = gdjs.LevelCode.GDEnemy33Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy33Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye4Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye4Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye4Objects2[k] = gdjs.LevelCode.GDmelteye4Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye4Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy322Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy322Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy322Objects2[k] = gdjs.LevelCode.GDEnemy322Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy322Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy32Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy32Objects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy32Objects2[k] = gdjs.LevelCode.GDEnemy32Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy32Objects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy22Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy32Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy322Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy33Objects2 */
/* Reuse gdjs.LevelCode.GDEnemy34Objects2 */
/* Reuse gdjs.LevelCode.GDmelteyeObjects2 */
/* Reuse gdjs.LevelCode.GDmelteye2Objects2 */
/* Reuse gdjs.LevelCode.GDmelteye3Objects2 */
/* Reuse gdjs.LevelCode.GDmelteye4Objects2 */
/* Reuse gdjs.LevelCode.GDnotbrainObjects2 */
/* Reuse gdjs.LevelCode.GDshootObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDEnemy32Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy322Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye4Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy33Objects2.length === 0 ) ? (( gdjs.LevelCode.GDshootObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy34Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy22Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye2Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDnotbrainObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy1Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteyeObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects2[0].getPointX("")) :gdjs.LevelCode.GDmelteyeObjects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy3Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy1Objects2[0].getPointX("")) :gdjs.LevelCode.GDnotbrainObjects2[0].getPointX("")) :gdjs.LevelCode.GDmelteye3Objects2[0].getPointX("")) :gdjs.LevelCode.GDmelteye2Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy22Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy34Objects2[0].getPointX("")) :gdjs.LevelCode.GDshootObjects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy33Objects2[0].getPointX("")) :gdjs.LevelCode.GDmelteye4Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy322Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy32Objects2[0].getPointX("")) + gdjs.randomInRange(-(10), 10), (( gdjs.LevelCode.GDEnemy32Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy322Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye4Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy33Objects2.length === 0 ) ? (( gdjs.LevelCode.GDshootObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy34Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy22Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye2Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDnotbrainObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy1Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteyeObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects2[0].getPointY("")) :gdjs.LevelCode.GDmelteyeObjects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy3Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy1Objects2[0].getPointY("")) :gdjs.LevelCode.GDnotbrainObjects2[0].getPointY("")) :gdjs.LevelCode.GDmelteye3Objects2[0].getPointY("")) :gdjs.LevelCode.GDmelteye2Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy22Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy34Objects2[0].getPointY("")) :gdjs.LevelCode.GDshootObjects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy33Objects2[0].getPointY("")) :gdjs.LevelCode.GDmelteye4Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy322Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy32Objects2[0].getPointY("")) + gdjs.randomInRange(-(10), 10), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDEnemy32Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy322Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye4Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy33Objects2.length === 0 ) ? (( gdjs.LevelCode.GDshootObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy34Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy22Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye2Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDnotbrainObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy1Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteyeObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects2[0].getPointX("")) :gdjs.LevelCode.GDmelteyeObjects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy3Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy1Objects2[0].getPointX("")) :gdjs.LevelCode.GDnotbrainObjects2[0].getPointX("")) :gdjs.LevelCode.GDmelteye3Objects2[0].getPointX("")) :gdjs.LevelCode.GDmelteye2Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy22Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy34Objects2[0].getPointX("")) :gdjs.LevelCode.GDshootObjects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy33Objects2[0].getPointX("")) :gdjs.LevelCode.GDmelteye4Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy322Objects2[0].getPointX("")) :gdjs.LevelCode.GDEnemy32Objects2[0].getPointX("")) + gdjs.randomInRange(-(10), 10), (( gdjs.LevelCode.GDEnemy32Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy322Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye4Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy33Objects2.length === 0 ) ? (( gdjs.LevelCode.GDshootObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy34Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy22Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye2Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteye3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDnotbrainObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy1Objects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy3Objects2.length === 0 ) ? (( gdjs.LevelCode.GDmelteyeObjects2.length === 0 ) ? (( gdjs.LevelCode.GDEnemy2Objects2.length === 0 ) ? 0 :gdjs.LevelCode.GDEnemy2Objects2[0].getPointY("")) :gdjs.LevelCode.GDmelteyeObjects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy3Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy1Objects2[0].getPointY("")) :gdjs.LevelCode.GDnotbrainObjects2[0].getPointY("")) :gdjs.LevelCode.GDmelteye3Objects2[0].getPointY("")) :gdjs.LevelCode.GDmelteye2Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy22Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy34Objects2[0].getPointY("")) :gdjs.LevelCode.GDshootObjects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy33Objects2[0].getPointY("")) :gdjs.LevelCode.GDmelteye4Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy322Objects2[0].getPointY("")) :gdjs.LevelCode.GDEnemy32Objects2[0].getPointY("")) + gdjs.randomInRange(-(10), 10), "");
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteyeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteyeObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDnotbrainObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDnotbrainObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy34Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDshootObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDshootObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy322Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy322Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy32Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ah.ogg", false, 20, 1);
}}

}


{

/* Reuse gdjs.LevelCode.GDEnemy1Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy22Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy32Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy322Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy33Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy34Objects1 */
/* Reuse gdjs.LevelCode.GDmelteyeObjects1 */
/* Reuse gdjs.LevelCode.GDmelteye2Objects1 */
/* Reuse gdjs.LevelCode.GDmelteye3Objects1 */
/* Reuse gdjs.LevelCode.GDmelteye4Objects1 */
/* Reuse gdjs.LevelCode.GDnotbrainObjects1 */
/* Reuse gdjs.LevelCode.GDshootObjects1 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy2Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy2Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy2Objects1[k] = gdjs.LevelCode.GDEnemy2Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteyeObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteyeObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteyeObjects1[k] = gdjs.LevelCode.GDmelteyeObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteyeObjects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy3Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy3Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy3Objects1[k] = gdjs.LevelCode.GDEnemy3Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy3Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy1Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy1Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy1Objects1[k] = gdjs.LevelCode.GDEnemy1Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy1Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDnotbrainObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDnotbrainObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDnotbrainObjects1[k] = gdjs.LevelCode.GDnotbrainObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDnotbrainObjects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye3Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye3Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye3Objects1[k] = gdjs.LevelCode.GDmelteye3Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye3Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye2Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye2Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye2Objects1[k] = gdjs.LevelCode.GDmelteye2Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy22Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy22Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy22Objects1[k] = gdjs.LevelCode.GDEnemy22Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy22Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy34Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy34Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy34Objects1[k] = gdjs.LevelCode.GDEnemy34Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy34Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDshootObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDshootObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDshootObjects1[k] = gdjs.LevelCode.GDshootObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDshootObjects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy33Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy33Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy33Objects1[k] = gdjs.LevelCode.GDEnemy33Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy33Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye4Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye4Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye4Objects1[k] = gdjs.LevelCode.GDmelteye4Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye4Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy322Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy322Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy322Objects1[k] = gdjs.LevelCode.GDEnemy322Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy322Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy32Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy32Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy32Objects1[k] = gdjs.LevelCode.GDEnemy32Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy32Objects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDEnemy1Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy2Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy22Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy3Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy32Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy322Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy33Objects1 */
/* Reuse gdjs.LevelCode.GDEnemy34Objects1 */
/* Reuse gdjs.LevelCode.GDmelteyeObjects1 */
/* Reuse gdjs.LevelCode.GDmelteye2Objects1 */
/* Reuse gdjs.LevelCode.GDmelteye3Objects1 */
/* Reuse gdjs.LevelCode.GDmelteye4Objects1 */
/* Reuse gdjs.LevelCode.GDnotbrainObjects1 */
/* Reuse gdjs.LevelCode.GDshootObjects1 */
{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteyeObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteyeObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDnotbrainObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDnotbrainObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye3Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye3Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye2Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye2Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy22Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy22Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy34Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy34Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDshootObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDshootObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye4Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye4Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy322Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy322Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy32Objects1.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy32Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.LevelCode.eventsList14 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.LevelCode.GDEnemy1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.LevelCode.GDEnemy2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.LevelCode.GDEnemy22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.LevelCode.GDEnemy3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy32"), gdjs.LevelCode.GDEnemy32Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy322"), gdjs.LevelCode.GDEnemy322Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy33"), gdjs.LevelCode.GDEnemy33Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy34"), gdjs.LevelCode.GDEnemy34Objects2);
gdjs.copyArray(runtimeScene.getObjects("melteye"), gdjs.LevelCode.GDmelteyeObjects2);
gdjs.copyArray(runtimeScene.getObjects("melteye2"), gdjs.LevelCode.GDmelteye2Objects2);
gdjs.copyArray(runtimeScene.getObjects("melteye3"), gdjs.LevelCode.GDmelteye3Objects2);
gdjs.copyArray(runtimeScene.getObjects("melteye4"), gdjs.LevelCode.GDmelteye4Objects2);
gdjs.copyArray(runtimeScene.getObjects("notbrain"), gdjs.LevelCode.GDnotbrainObjects2);
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.LevelCode.GDshootObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].activateBehavior("LinearMovement", false);
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].activateBehavior("LinearMovement", true);
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].activateBehavior("LinearMovement", true);
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy34Objects2[i].activateBehavior("LinearMovement", true);
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].activateBehavior("LinearMovement", true);
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].activateBehavior("LinearMovement", true);
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy2Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteyeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteyeObjects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy3Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy1Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDnotbrainObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDnotbrainObjects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye3Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye3Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye2Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye2Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy22Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy34Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy34Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDshootObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDshootObjects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy33Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy33Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDmelteye4Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDmelteye4Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy322Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy322Objects2[i].activateBehavior("LinearMovement", true);
}
for(var i = 0, len = gdjs.LevelCode.GDEnemy32Objects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemy32Objects2[i].activateBehavior("LinearMovement", true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.LevelCode.GDEnemy1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.LevelCode.GDEnemy2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.LevelCode.GDEnemy22Objects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.LevelCode.GDEnemy3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy32"), gdjs.LevelCode.GDEnemy32Objects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy322"), gdjs.LevelCode.GDEnemy322Objects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy33"), gdjs.LevelCode.GDEnemy33Objects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy34"), gdjs.LevelCode.GDEnemy34Objects1);
gdjs.copyArray(runtimeScene.getObjects("melteye"), gdjs.LevelCode.GDmelteyeObjects1);
gdjs.copyArray(runtimeScene.getObjects("melteye2"), gdjs.LevelCode.GDmelteye2Objects1);
gdjs.copyArray(runtimeScene.getObjects("melteye3"), gdjs.LevelCode.GDmelteye3Objects1);
gdjs.copyArray(runtimeScene.getObjects("melteye4"), gdjs.LevelCode.GDmelteye4Objects1);
gdjs.copyArray(runtimeScene.getObjects("notbrain"), gdjs.LevelCode.GDnotbrainObjects1);
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.LevelCode.GDshootObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy2Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy2Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy2Objects1[k] = gdjs.LevelCode.GDEnemy2Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteyeObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteyeObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteyeObjects1[k] = gdjs.LevelCode.GDmelteyeObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteyeObjects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy3Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy3Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy3Objects1[k] = gdjs.LevelCode.GDEnemy3Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy3Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy1Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy1Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy1Objects1[k] = gdjs.LevelCode.GDEnemy1Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy1Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDnotbrainObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDnotbrainObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDnotbrainObjects1[k] = gdjs.LevelCode.GDnotbrainObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDnotbrainObjects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye3Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye3Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye3Objects1[k] = gdjs.LevelCode.GDmelteye3Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye3Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye2Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye2Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye2Objects1[k] = gdjs.LevelCode.GDmelteye2Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye2Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy22Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy22Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy22Objects1[k] = gdjs.LevelCode.GDEnemy22Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy22Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy34Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy34Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy34Objects1[k] = gdjs.LevelCode.GDEnemy34Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy34Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDshootObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDshootObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDshootObjects1[k] = gdjs.LevelCode.GDshootObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDshootObjects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy33Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy33Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy33Objects1[k] = gdjs.LevelCode.GDEnemy33Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy33Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye4Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye4Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye4Objects1[k] = gdjs.LevelCode.GDmelteye4Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye4Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy322Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy322Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy322Objects1[k] = gdjs.LevelCode.GDEnemy322Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy322Objects1.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy32Objects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy32Objects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy32Objects1[k] = gdjs.LevelCode.GDEnemy32Objects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy32Objects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LevelCode.GDPlayerObjects1});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDHealthPackObjects1Objects = Hashtable.newFrom({"HealthPack": gdjs.LevelCode.GDHealthPackObjects1});gdjs.LevelCode.eventsList15 = function(runtimeScene) {

{

/* Reuse gdjs.LevelCode.GDHealthPackObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerObjects1Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDHealthPackObjects1Objects, false, runtimeScene, false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDHealthPackObjects1 */
/* Reuse gdjs.LevelCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.LevelCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerObjects1[i].getBehavior("Health").Heal(50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LevelCode.GDHealthPackObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDHealthPackObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "bagavheal.ogg", false, 80, 1);
}}

}


};gdjs.LevelCode.eventsList16 = function(runtimeScene) {

{



}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HealthPack"), gdjs.LevelCode.GDHealthPackObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDHealthPackObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDHealthPackObjects2[i].activateBehavior("SineMovement", false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HealthPack"), gdjs.LevelCode.GDHealthPackObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDHealthPackObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDHealthPackObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) / 2 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDHealthPackObjects1[k] = gdjs.LevelCode.GDHealthPackObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDHealthPackObjects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDHealthPackObjects1 */
{for(var i = 0, len = gdjs.LevelCode.GDHealthPackObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDHealthPackObjects1[i].activateBehavior("SineMovement", true);
}
}
{ //Subevents
gdjs.LevelCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Explosion"), gdjs.LevelCode.GDExplosionObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDExplosionObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDExplosionObjects2[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDExplosionObjects2[k] = gdjs.LevelCode.GDExplosionObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDExplosionObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDExplosionObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDExplosionObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDExplosionObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Explosion"), gdjs.LevelCode.GDExplosionObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDExplosionObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDExplosionObjects1[i].setZOrder(50);
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDFadeObjects2Objects = Hashtable.newFrom({"Fade": gdjs.LevelCode.GDFadeObjects2});gdjs.LevelCode.eventsList18 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11463476);
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "GameOver");
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "GameOver");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level", false);
}}

}


};gdjs.LevelCode.eventsList19 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11465580);
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "LevelComplete");
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 4, "LevelComplete");
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level", false);
}}

}


};gdjs.LevelCode.eventsList20 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("DISPLAY_SCORE"), gdjs.LevelCode.GDDISPLAY_95SCOREObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDDISPLAY_95SCOREObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDDISPLAY_95SCOREObjects2[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(3)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.LevelCode.GDEnemy1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.LevelCode.GDEnemy2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.LevelCode.GDEnemy22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.LevelCode.GDEnemy3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy32"), gdjs.LevelCode.GDEnemy32Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy322"), gdjs.LevelCode.GDEnemy322Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy33"), gdjs.LevelCode.GDEnemy33Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy34"), gdjs.LevelCode.GDEnemy34Objects2);
gdjs.copyArray(runtimeScene.getObjects("melteye"), gdjs.LevelCode.GDmelteyeObjects2);
gdjs.copyArray(runtimeScene.getObjects("melteye2"), gdjs.LevelCode.GDmelteye2Objects2);
gdjs.copyArray(runtimeScene.getObjects("melteye3"), gdjs.LevelCode.GDmelteye3Objects2);
gdjs.copyArray(runtimeScene.getObjects("melteye4"), gdjs.LevelCode.GDmelteye4Objects2);
gdjs.copyArray(runtimeScene.getObjects("notbrain"), gdjs.LevelCode.GDnotbrainObjects2);
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.LevelCode.GDshootObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy2Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy2Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy2Objects2[k] = gdjs.LevelCode.GDEnemy2Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteyeObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteyeObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteyeObjects2[k] = gdjs.LevelCode.GDmelteyeObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteyeObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy3Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy3Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy3Objects2[k] = gdjs.LevelCode.GDEnemy3Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy3Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy1Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy1Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy1Objects2[k] = gdjs.LevelCode.GDEnemy1Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDnotbrainObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDnotbrainObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDnotbrainObjects2[k] = gdjs.LevelCode.GDnotbrainObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDnotbrainObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye3Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye3Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye3Objects2[k] = gdjs.LevelCode.GDmelteye3Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye3Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye2Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye2Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye2Objects2[k] = gdjs.LevelCode.GDmelteye2Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy22Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy22Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy22Objects2[k] = gdjs.LevelCode.GDEnemy22Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy22Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy34Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy34Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy34Objects2[k] = gdjs.LevelCode.GDEnemy34Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy34Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDshootObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDshootObjects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDshootObjects2[k] = gdjs.LevelCode.GDshootObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDshootObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy33Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy33Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy33Objects2[k] = gdjs.LevelCode.GDEnemy33Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy33Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDmelteye4Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDmelteye4Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDmelteye4Objects2[k] = gdjs.LevelCode.GDmelteye4Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDmelteye4Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy322Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy322Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy322Objects2[k] = gdjs.LevelCode.GDEnemy322Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy322Objects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDEnemy32Objects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDEnemy32Objects2[i].getBehavior("Health").IsJustDamaged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDEnemy32Objects2[k] = gdjs.LevelCode.GDEnemy32Objects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDEnemy32Objects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).add(1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Lifebar"), gdjs.LevelCode.GDLifebarObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LevelCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDLifebarObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDLifebarObjects2[i].setScaleX((( gdjs.LevelCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / 100);
}
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.LevelCode.GDGameOverObjects2);
gdjs.LevelCode.GDFadeObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDFadeObjects2Objects, 0, 0, "UI");
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].setWidth(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene));
}
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].setHeight(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene));
}
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.LevelCode.GDGameOverObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDGameOverObjects2[i].hide();
}
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Fade"), gdjs.LevelCode.GDFadeObjects2);
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.LevelCode.GDGameOverObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].setOpacity(gdjs.LevelCode.GDFadeObjects2[i].getOpacity() + (128 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.LevelCode.GDGameOverObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDGameOverObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.LevelCode.eventsList18(runtimeScene);} //End of subevents
}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 1;
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Fade"), gdjs.LevelCode.GDFadeObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects1[i].setOpacity(gdjs.LevelCode.GDFadeObjects1[i].getOpacity() + (128 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.LevelCode.GDFadeObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDFadeObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.LevelCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossTopArmObjects2ObjectsGDgdjs_46LevelCode_46GDBossBottomArmObjects2Objects = Hashtable.newFrom({"BossTopArm": gdjs.LevelCode.GDBossTopArmObjects2, "BossBottomArm": gdjs.LevelCode.GDBossBottomArmObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects = Hashtable.newFrom({"PlayerBullet": gdjs.LevelCode.GDPlayerBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossTopArmObjects2ObjectsGDgdjs_46LevelCode_46GDBossBottomArmObjects2Objects = Hashtable.newFrom({"BossTopArm": gdjs.LevelCode.GDBossTopArmObjects2, "BossBottomArm": gdjs.LevelCode.GDBossBottomArmObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects = Hashtable.newFrom({"PlayerAttackArea": gdjs.LevelCode.GDPlayerAttackAreaObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects5Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects5});gdjs.LevelCode.eventsList21 = function(runtimeScene) {

};gdjs.LevelCode.eventsList22 = function(runtimeScene) {

{


gdjs.LevelCode.repeatCount5 = 3;
for(gdjs.LevelCode.repeatIndex5 = 0;gdjs.LevelCode.repeatIndex5 < gdjs.LevelCode.repeatCount5;++gdjs.LevelCode.repeatIndex5) {
gdjs.copyArray(gdjs.LevelCode.GDBossBottomArmObjects3, gdjs.LevelCode.GDBossBottomArmObjects5);

gdjs.copyArray(gdjs.LevelCode.GDBossTopArmObjects3, gdjs.LevelCode.GDBossTopArmObjects5);

gdjs.LevelCode.GDExplosionObjects5.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects5Objects, (( gdjs.LevelCode.GDBossBottomArmObjects5.length === 0 ) ? (( gdjs.LevelCode.GDBossTopArmObjects5.length === 0 ) ? 0 :gdjs.LevelCode.GDBossTopArmObjects5[0].getPointX("Bullets")) :gdjs.LevelCode.GDBossBottomArmObjects5[0].getPointX("Bullets")) + gdjs.randomInRange(-(10), 10), (( gdjs.LevelCode.GDBossBottomArmObjects5.length === 0 ) ? (( gdjs.LevelCode.GDBossTopArmObjects5.length === 0 ) ? 0 :gdjs.LevelCode.GDBossTopArmObjects5[0].getPointY("Bullets")) :gdjs.LevelCode.GDBossBottomArmObjects5[0].getPointY("Bullets")) + gdjs.randomInRange(-(10), 10), "");
}}
}

}


};gdjs.LevelCode.eventsList23 = function(runtimeScene) {

{

/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */

gdjs.LevelCode.forEachTotalCount3 = 0;
gdjs.LevelCode.forEachObjects3.length = 0;
gdjs.LevelCode.forEachCount0_3 = gdjs.LevelCode.GDBossTopArmObjects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount0_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDBossTopArmObjects2);
gdjs.LevelCode.forEachCount1_3 = gdjs.LevelCode.GDBossBottomArmObjects2.length;
gdjs.LevelCode.forEachTotalCount3 += gdjs.LevelCode.forEachCount1_3;
gdjs.LevelCode.forEachObjects3.push.apply(gdjs.LevelCode.forEachObjects3,gdjs.LevelCode.GDBossBottomArmObjects2);
for(gdjs.LevelCode.forEachIndex3 = 0;gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachTotalCount3;++gdjs.LevelCode.forEachIndex3) {
gdjs.LevelCode.GDBossBottomArmObjects3.length = 0;

gdjs.LevelCode.GDBossTopArmObjects3.length = 0;


if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3) {
    gdjs.LevelCode.GDBossTopArmObjects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
else if (gdjs.LevelCode.forEachIndex3 < gdjs.LevelCode.forEachCount0_3+gdjs.LevelCode.forEachCount1_3) {
    gdjs.LevelCode.GDBossBottomArmObjects3.push(gdjs.LevelCode.forEachObjects3[gdjs.LevelCode.forEachIndex3]);
}
if (true) {

{ //Subevents: 
gdjs.LevelCode.eventsList22(runtimeScene);} //Subevents end.
}
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossBodyObjects2Objects = Hashtable.newFrom({"BossBody": gdjs.LevelCode.GDBossBodyObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects = Hashtable.newFrom({"PlayerBullet": gdjs.LevelCode.GDPlayerBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.LevelCode.GDEnemyBulletObjects2});gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossSuperLaserObjects2Objects = Hashtable.newFrom({"BossSuperLaser": gdjs.LevelCode.GDBossSuperLaserObjects2});gdjs.LevelCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].setAnimationName("Deploy");
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].setAnimationName("Deploy");
}
}}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.LevelCode.GDExplosionObjects1});gdjs.LevelCode.eventsList25 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11486804);
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);

{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].resetTimer("DeathExplosions");
}
}{runtimeScene.getVariables().getFromIndex(2).setNumber(1);
}}

}


{


{
{gdjs.evtsExt__VibratingCamera__VibrateCameraAroundPosition.func(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), 4, 6, 50, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

/* Reuse gdjs.LevelCode.GDBossBodyObjects1 */

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects1[i].timerElapsedTime("DeathExplosions", 0.08) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects1[k] = gdjs.LevelCode.GDBossBodyObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects1 */
gdjs.LevelCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects1Objects, (( gdjs.LevelCode.GDBossBodyObjects1.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects1[0].getPointX("")) + gdjs.random(40), (( gdjs.LevelCode.GDBossBodyObjects1.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects1[0].getPointY("")) + gdjs.random((( gdjs.LevelCode.GDBossBodyObjects1.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects1[0].getHeight())), "");
}{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects1[i].resetTimer("DeathExplosions");
}
}}

}


};gdjs.LevelCode.eventsList26 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition0IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11468100);
}
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);

{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].resetTimer("LaserAttack");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.LevelCode.GDPlayerBulletObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossTopArmObjects2ObjectsGDgdjs_46LevelCode_46GDBossBottomArmObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
/* Reuse gdjs.LevelCode.GDPlayerBulletObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointX("")) + 5, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerAttackArea"), gdjs.LevelCode.GDPlayerAttackAreaObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossTopArmObjects2ObjectsGDgdjs_46LevelCode_46GDBossBottomArmObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerAttackAreaObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition2IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11471036);
}
}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.LevelCode.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);

gdjs.copyArray(runtimeScene.getObjects("PlayerBullet"), gdjs.LevelCode.GDPlayerBulletObjects2);
gdjs.LevelCode.GDBossBottomArmObjects2.length = 0;

gdjs.LevelCode.GDBossTopArmObjects2.length = 0;


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossBodyObjects2Objects, gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPlayerBulletObjects2Objects, false, runtimeScene, false);
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition1IsTrue_0;
gdjs.LevelCode.GDBossBottomArmObjects2_1final.length = 0;gdjs.LevelCode.GDBossTopArmObjects2_1final.length = 0;gdjs.LevelCode.condition0IsTrue_1.val = false;
gdjs.LevelCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects3);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects3);
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects3[i].isCurrentAnimationName("Retract") ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDBossTopArmObjects3[k] = gdjs.LevelCode.GDBossTopArmObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects3[i].isCurrentAnimationName("Retract") ) {
        gdjs.LevelCode.condition0IsTrue_1.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects3[k] = gdjs.LevelCode.GDBossBottomArmObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects3.length = k;if( gdjs.LevelCode.condition0IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDBossBottomArmObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDBossBottomArmObjects2_1final.indexOf(gdjs.LevelCode.GDBossBottomArmObjects3[j]) === -1 )
            gdjs.LevelCode.GDBossBottomArmObjects2_1final.push(gdjs.LevelCode.GDBossBottomArmObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDBossTopArmObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDBossTopArmObjects2_1final.indexOf(gdjs.LevelCode.GDBossTopArmObjects3[j]) === -1 )
            gdjs.LevelCode.GDBossTopArmObjects2_1final.push(gdjs.LevelCode.GDBossTopArmObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects3);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects3);
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects3[i].isCurrentAnimationName("Broken") ) {
        gdjs.LevelCode.condition1IsTrue_1.val = true;
        gdjs.LevelCode.GDBossTopArmObjects3[k] = gdjs.LevelCode.GDBossTopArmObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects3.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects3.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects3[i].isCurrentAnimationName("Broken") ) {
        gdjs.LevelCode.condition1IsTrue_1.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects3[k] = gdjs.LevelCode.GDBossBottomArmObjects3[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects3.length = k;if( gdjs.LevelCode.condition1IsTrue_1.val ) {
    gdjs.LevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.LevelCode.GDBossBottomArmObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDBossBottomArmObjects2_1final.indexOf(gdjs.LevelCode.GDBossBottomArmObjects3[j]) === -1 )
            gdjs.LevelCode.GDBossBottomArmObjects2_1final.push(gdjs.LevelCode.GDBossBottomArmObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.LevelCode.GDBossTopArmObjects3.length;j<jLen;++j) {
        if ( gdjs.LevelCode.GDBossTopArmObjects2_1final.indexOf(gdjs.LevelCode.GDBossTopArmObjects3[j]) === -1 )
            gdjs.LevelCode.GDBossTopArmObjects2_1final.push(gdjs.LevelCode.GDBossTopArmObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LevelCode.GDBossBottomArmObjects2_1final, gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(gdjs.LevelCode.GDBossTopArmObjects2_1final, gdjs.LevelCode.GDBossTopArmObjects2);
}
}
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
/* Reuse gdjs.LevelCode.GDPlayerBulletObjects2 */
gdjs.LevelCode.GDExplosionObjects2.length = 0;

{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDExplosionObjects2Objects, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointX("")) + 5, (( gdjs.LevelCode.GDPlayerBulletObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDPlayerBulletObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.LevelCode.GDPlayerBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDPlayerBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].isCurrentAnimationName("Deploy") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].isCurrentAnimationName("Deploy") ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].setAnimationName("Idle");
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].isCurrentAnimationName("Idle") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossBodyObjects2[i].timerElapsedTime("LaserAttack", 2)) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.LevelCode.GDEnemyBulletObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDBossTopArmObjects2[i].getPointX("Bullets")), (gdjs.LevelCode.GDBossTopArmObjects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("FireBullet").Fire((gdjs.LevelCode.GDBossBottomArmObjects2[i].getPointX("Bullets")), (gdjs.LevelCode.GDBossBottomArmObjects2[i].getPointY("Bullets")), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDEnemyBulletObjects2Objects, 180, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LevelCode.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDEnemyBulletObjects2[i].setZOrder(20);
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].timerElapsedTime("LaserAttack", 4) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition2IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11477308);
}
}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].setAnimationName("Retract");
}
for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].setAnimationName("Retract");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].timerElapsedTime("LaserAttack", 5) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossBodyObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition2IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11478476);
}
}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].setAnimationName("Attack");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].isCurrentAnimationName("Attack") ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].hasAnimationEnded() ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition2IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11479692);
}
}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
gdjs.LevelCode.GDBossSuperLaserObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDBossSuperLaserObjects2Objects, (( gdjs.LevelCode.GDBossBodyObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects2[0].getPointX("Left")), (( gdjs.LevelCode.GDBossBodyObjects2.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects2[0].getPointY("Center")), "");
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].timerElapsedTime("LaserAttack", 7) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDBossBodyObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
{gdjs.LevelCode.conditionTrue_1 = gdjs.LevelCode.condition2IsTrue_0;
gdjs.LevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11479940);
}
}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("BossSuperLaser"), gdjs.LevelCode.GDBossSuperLaserObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.LevelCode.GDBossSuperLaserObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossSuperLaserObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].timerElapsedTime("LaserAttack", 7.5) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].resetTimer("LaserAttack");
}
}
{ //Subevents
gdjs.LevelCode.eventsList24(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects2[k] = gdjs.LevelCode.GDBossBottomArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBottomArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossBottomArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBottomArmObjects2[i].setAnimationName("Broken");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects2);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects2[k] = gdjs.LevelCode.GDBossTopArmObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossTopArmObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossTopArmObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossTopArmObjects2[i].setAnimationName("Broken");
}
}}

}


{

gdjs.copyArray(gdjs.LevelCode.GDBossBodyObjects1, gdjs.LevelCode.GDBossBodyObjects2);


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects2.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects2[k] = gdjs.LevelCode.GDBossBodyObjects2[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects2.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects2 */
{for(var i = 0, len = gdjs.LevelCode.GDBossBodyObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDBossBodyObjects2[i].setAnimationName("Broken");
}
}}

}


{

/* Reuse gdjs.LevelCode.GDBossBodyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("BossBottomArm"), gdjs.LevelCode.GDBossBottomArmObjects1);
gdjs.copyArray(runtimeScene.getObjects("BossTopArm"), gdjs.LevelCode.GDBossTopArmObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
gdjs.LevelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects1[k] = gdjs.LevelCode.GDBossBodyObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects1.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBottomArmObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBottomArmObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition1IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBottomArmObjects1[k] = gdjs.LevelCode.GDBossBottomArmObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBottomArmObjects1.length = k;}if ( gdjs.LevelCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossTopArmObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossTopArmObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition2IsTrue_0.val = true;
        gdjs.LevelCode.GDBossTopArmObjects1[k] = gdjs.LevelCode.GDBossTopArmObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossTopArmObjects1.length = k;}}
}
if (gdjs.LevelCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BossBody"), gdjs.LevelCode.GDBossBodyObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDBossBodyObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDBossBodyObjects1[i].getX() <= gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + 32 ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDBossBodyObjects1[k] = gdjs.LevelCode.GDBossBodyObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDBossBodyObjects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelCode.GDBossBodyObjects1 */
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.LevelCode.GDBossBodyObjects1.length === 0 ) ? 0 :gdjs.LevelCode.GDBossBodyObjects1[0].getPointX("")) - 32, "", 0);
}
{ //Subevents
gdjs.LevelCode.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.LevelCode.eventsList28 = function(runtimeScene) {

{


gdjs.LevelCode.eventsList9(runtimeScene);
}


{


gdjs.LevelCode.eventsList14(runtimeScene);
}


{


gdjs.LevelCode.eventsList16(runtimeScene);
}


{


gdjs.LevelCode.eventsList17(runtimeScene);
}


{


gdjs.LevelCode.eventsList20(runtimeScene);
}


{


gdjs.LevelCode.eventsList27(runtimeScene);
}


};

gdjs.LevelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LevelCode.GDPlayerObjects1.length = 0;
gdjs.LevelCode.GDPlayerObjects2.length = 0;
gdjs.LevelCode.GDPlayerObjects3.length = 0;
gdjs.LevelCode.GDPlayerObjects4.length = 0;
gdjs.LevelCode.GDPlayerObjects5.length = 0;
gdjs.LevelCode.GDPlayerObjects6.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects1.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects2.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects3.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects4.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects5.length = 0;
gdjs.LevelCode.GDSpaceBackgroundObjects6.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects1.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects2.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects3.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects4.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects5.length = 0;
gdjs.LevelCode.GDCorridorBackgroundObjects6.length = 0;
gdjs.LevelCode.GDsalesObjects1.length = 0;
gdjs.LevelCode.GDsalesObjects2.length = 0;
gdjs.LevelCode.GDsalesObjects3.length = 0;
gdjs.LevelCode.GDsalesObjects4.length = 0;
gdjs.LevelCode.GDsalesObjects5.length = 0;
gdjs.LevelCode.GDsalesObjects6.length = 0;
gdjs.LevelCode.GDarrowObjects1.length = 0;
gdjs.LevelCode.GDarrowObjects2.length = 0;
gdjs.LevelCode.GDarrowObjects3.length = 0;
gdjs.LevelCode.GDarrowObjects4.length = 0;
gdjs.LevelCode.GDarrowObjects5.length = 0;
gdjs.LevelCode.GDarrowObjects6.length = 0;
gdjs.LevelCode.GDlambdafriendObjects1.length = 0;
gdjs.LevelCode.GDlambdafriendObjects2.length = 0;
gdjs.LevelCode.GDlambdafriendObjects3.length = 0;
gdjs.LevelCode.GDlambdafriendObjects4.length = 0;
gdjs.LevelCode.GDlambdafriendObjects5.length = 0;
gdjs.LevelCode.GDlambdafriendObjects6.length = 0;
gdjs.LevelCode.GDshootObjects1.length = 0;
gdjs.LevelCode.GDshootObjects2.length = 0;
gdjs.LevelCode.GDshootObjects3.length = 0;
gdjs.LevelCode.GDshootObjects4.length = 0;
gdjs.LevelCode.GDshootObjects5.length = 0;
gdjs.LevelCode.GDshootObjects6.length = 0;
gdjs.LevelCode.GDnotbrainObjects1.length = 0;
gdjs.LevelCode.GDnotbrainObjects2.length = 0;
gdjs.LevelCode.GDnotbrainObjects3.length = 0;
gdjs.LevelCode.GDnotbrainObjects4.length = 0;
gdjs.LevelCode.GDnotbrainObjects5.length = 0;
gdjs.LevelCode.GDnotbrainObjects6.length = 0;
gdjs.LevelCode.GDmelteye2Objects1.length = 0;
gdjs.LevelCode.GDmelteye2Objects2.length = 0;
gdjs.LevelCode.GDmelteye2Objects3.length = 0;
gdjs.LevelCode.GDmelteye2Objects4.length = 0;
gdjs.LevelCode.GDmelteye2Objects5.length = 0;
gdjs.LevelCode.GDmelteye2Objects6.length = 0;
gdjs.LevelCode.GDmelteye3Objects1.length = 0;
gdjs.LevelCode.GDmelteye3Objects2.length = 0;
gdjs.LevelCode.GDmelteye3Objects3.length = 0;
gdjs.LevelCode.GDmelteye3Objects4.length = 0;
gdjs.LevelCode.GDmelteye3Objects5.length = 0;
gdjs.LevelCode.GDmelteye3Objects6.length = 0;
gdjs.LevelCode.GDmelteye4Objects1.length = 0;
gdjs.LevelCode.GDmelteye4Objects2.length = 0;
gdjs.LevelCode.GDmelteye4Objects3.length = 0;
gdjs.LevelCode.GDmelteye4Objects4.length = 0;
gdjs.LevelCode.GDmelteye4Objects5.length = 0;
gdjs.LevelCode.GDmelteye4Objects6.length = 0;
gdjs.LevelCode.GDmelteyeObjects1.length = 0;
gdjs.LevelCode.GDmelteyeObjects2.length = 0;
gdjs.LevelCode.GDmelteyeObjects3.length = 0;
gdjs.LevelCode.GDmelteyeObjects4.length = 0;
gdjs.LevelCode.GDmelteyeObjects5.length = 0;
gdjs.LevelCode.GDmelteyeObjects6.length = 0;
gdjs.LevelCode.GDEnemy22Objects1.length = 0;
gdjs.LevelCode.GDEnemy22Objects2.length = 0;
gdjs.LevelCode.GDEnemy22Objects3.length = 0;
gdjs.LevelCode.GDEnemy22Objects4.length = 0;
gdjs.LevelCode.GDEnemy22Objects5.length = 0;
gdjs.LevelCode.GDEnemy22Objects6.length = 0;
gdjs.LevelCode.GDEnemy2Objects1.length = 0;
gdjs.LevelCode.GDEnemy2Objects2.length = 0;
gdjs.LevelCode.GDEnemy2Objects3.length = 0;
gdjs.LevelCode.GDEnemy2Objects4.length = 0;
gdjs.LevelCode.GDEnemy2Objects5.length = 0;
gdjs.LevelCode.GDEnemy2Objects6.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects1.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects2.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects3.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects4.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects5.length = 0;
gdjs.LevelCode.GDPlayerBulletObjects6.length = 0;
gdjs.LevelCode.GDHealthPackObjects1.length = 0;
gdjs.LevelCode.GDHealthPackObjects2.length = 0;
gdjs.LevelCode.GDHealthPackObjects3.length = 0;
gdjs.LevelCode.GDHealthPackObjects4.length = 0;
gdjs.LevelCode.GDHealthPackObjects5.length = 0;
gdjs.LevelCode.GDHealthPackObjects6.length = 0;
gdjs.LevelCode.GDExplosionObjects1.length = 0;
gdjs.LevelCode.GDExplosionObjects2.length = 0;
gdjs.LevelCode.GDExplosionObjects3.length = 0;
gdjs.LevelCode.GDExplosionObjects4.length = 0;
gdjs.LevelCode.GDExplosionObjects5.length = 0;
gdjs.LevelCode.GDExplosionObjects6.length = 0;
gdjs.LevelCode.GDEnemy322Objects1.length = 0;
gdjs.LevelCode.GDEnemy322Objects2.length = 0;
gdjs.LevelCode.GDEnemy322Objects3.length = 0;
gdjs.LevelCode.GDEnemy322Objects4.length = 0;
gdjs.LevelCode.GDEnemy322Objects5.length = 0;
gdjs.LevelCode.GDEnemy322Objects6.length = 0;
gdjs.LevelCode.GDEnemy32Objects1.length = 0;
gdjs.LevelCode.GDEnemy32Objects2.length = 0;
gdjs.LevelCode.GDEnemy32Objects3.length = 0;
gdjs.LevelCode.GDEnemy32Objects4.length = 0;
gdjs.LevelCode.GDEnemy32Objects5.length = 0;
gdjs.LevelCode.GDEnemy32Objects6.length = 0;
gdjs.LevelCode.GDEnemy34Objects1.length = 0;
gdjs.LevelCode.GDEnemy34Objects2.length = 0;
gdjs.LevelCode.GDEnemy34Objects3.length = 0;
gdjs.LevelCode.GDEnemy34Objects4.length = 0;
gdjs.LevelCode.GDEnemy34Objects5.length = 0;
gdjs.LevelCode.GDEnemy34Objects6.length = 0;
gdjs.LevelCode.GDEnemy33Objects1.length = 0;
gdjs.LevelCode.GDEnemy33Objects2.length = 0;
gdjs.LevelCode.GDEnemy33Objects3.length = 0;
gdjs.LevelCode.GDEnemy33Objects4.length = 0;
gdjs.LevelCode.GDEnemy33Objects5.length = 0;
gdjs.LevelCode.GDEnemy33Objects6.length = 0;
gdjs.LevelCode.GDEnemy3Objects1.length = 0;
gdjs.LevelCode.GDEnemy3Objects2.length = 0;
gdjs.LevelCode.GDEnemy3Objects3.length = 0;
gdjs.LevelCode.GDEnemy3Objects4.length = 0;
gdjs.LevelCode.GDEnemy3Objects5.length = 0;
gdjs.LevelCode.GDEnemy3Objects6.length = 0;
gdjs.LevelCode.GDEnemyBullet2Objects1.length = 0;
gdjs.LevelCode.GDEnemyBullet2Objects2.length = 0;
gdjs.LevelCode.GDEnemyBullet2Objects3.length = 0;
gdjs.LevelCode.GDEnemyBullet2Objects4.length = 0;
gdjs.LevelCode.GDEnemyBullet2Objects5.length = 0;
gdjs.LevelCode.GDEnemyBullet2Objects6.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects1.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects2.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects3.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects4.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects5.length = 0;
gdjs.LevelCode.GDEnemyBulletObjects6.length = 0;
gdjs.LevelCode.GDEnemy1Objects1.length = 0;
gdjs.LevelCode.GDEnemy1Objects2.length = 0;
gdjs.LevelCode.GDEnemy1Objects3.length = 0;
gdjs.LevelCode.GDEnemy1Objects4.length = 0;
gdjs.LevelCode.GDEnemy1Objects5.length = 0;
gdjs.LevelCode.GDEnemy1Objects6.length = 0;
gdjs.LevelCode.GDAttackFlameObjects1.length = 0;
gdjs.LevelCode.GDAttackFlameObjects2.length = 0;
gdjs.LevelCode.GDAttackFlameObjects3.length = 0;
gdjs.LevelCode.GDAttackFlameObjects4.length = 0;
gdjs.LevelCode.GDAttackFlameObjects5.length = 0;
gdjs.LevelCode.GDAttackFlameObjects6.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects1.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects2.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects3.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects4.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects5.length = 0;
gdjs.LevelCode.GDLifebarContainerObjects6.length = 0;
gdjs.LevelCode.GDLifebarObjects1.length = 0;
gdjs.LevelCode.GDLifebarObjects2.length = 0;
gdjs.LevelCode.GDLifebarObjects3.length = 0;
gdjs.LevelCode.GDLifebarObjects4.length = 0;
gdjs.LevelCode.GDLifebarObjects5.length = 0;
gdjs.LevelCode.GDLifebarObjects6.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects1.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects2.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects3.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects4.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects5.length = 0;
gdjs.LevelCode.GDPlayerAttackAreaObjects6.length = 0;
gdjs.LevelCode.GDChangeButtonObjects1.length = 0;
gdjs.LevelCode.GDChangeButtonObjects2.length = 0;
gdjs.LevelCode.GDChangeButtonObjects3.length = 0;
gdjs.LevelCode.GDChangeButtonObjects4.length = 0;
gdjs.LevelCode.GDChangeButtonObjects5.length = 0;
gdjs.LevelCode.GDChangeButtonObjects6.length = 0;
gdjs.LevelCode.GDBossBodyObjects1.length = 0;
gdjs.LevelCode.GDBossBodyObjects2.length = 0;
gdjs.LevelCode.GDBossBodyObjects3.length = 0;
gdjs.LevelCode.GDBossBodyObjects4.length = 0;
gdjs.LevelCode.GDBossBodyObjects5.length = 0;
gdjs.LevelCode.GDBossBodyObjects6.length = 0;
gdjs.LevelCode.GDBossTopArmObjects1.length = 0;
gdjs.LevelCode.GDBossTopArmObjects2.length = 0;
gdjs.LevelCode.GDBossTopArmObjects3.length = 0;
gdjs.LevelCode.GDBossTopArmObjects4.length = 0;
gdjs.LevelCode.GDBossTopArmObjects5.length = 0;
gdjs.LevelCode.GDBossTopArmObjects6.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects1.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects2.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects3.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects4.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects5.length = 0;
gdjs.LevelCode.GDBossBottomArmObjects6.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects1.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects2.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects3.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects4.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects5.length = 0;
gdjs.LevelCode.GDBossSuperLaserObjects6.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects1.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects2.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects3.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects4.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects5.length = 0;
gdjs.LevelCode.GDBossBackgroundObjects6.length = 0;
gdjs.LevelCode.GDFadeObjects1.length = 0;
gdjs.LevelCode.GDFadeObjects2.length = 0;
gdjs.LevelCode.GDFadeObjects3.length = 0;
gdjs.LevelCode.GDFadeObjects4.length = 0;
gdjs.LevelCode.GDFadeObjects5.length = 0;
gdjs.LevelCode.GDFadeObjects6.length = 0;
gdjs.LevelCode.GDGameOverObjects1.length = 0;
gdjs.LevelCode.GDGameOverObjects2.length = 0;
gdjs.LevelCode.GDGameOverObjects3.length = 0;
gdjs.LevelCode.GDGameOverObjects4.length = 0;
gdjs.LevelCode.GDGameOverObjects5.length = 0;
gdjs.LevelCode.GDGameOverObjects6.length = 0;
gdjs.LevelCode.GDDISPLAY_95SCOREObjects1.length = 0;
gdjs.LevelCode.GDDISPLAY_95SCOREObjects2.length = 0;
gdjs.LevelCode.GDDISPLAY_95SCOREObjects3.length = 0;
gdjs.LevelCode.GDDISPLAY_95SCOREObjects4.length = 0;
gdjs.LevelCode.GDDISPLAY_95SCOREObjects5.length = 0;
gdjs.LevelCode.GDDISPLAY_95SCOREObjects6.length = 0;
gdjs.LevelCode.GDrevenueObjects1.length = 0;
gdjs.LevelCode.GDrevenueObjects2.length = 0;
gdjs.LevelCode.GDrevenueObjects3.length = 0;
gdjs.LevelCode.GDrevenueObjects4.length = 0;
gdjs.LevelCode.GDrevenueObjects5.length = 0;
gdjs.LevelCode.GDrevenueObjects6.length = 0;
gdjs.LevelCode.GDspaceObjects1.length = 0;
gdjs.LevelCode.GDspaceObjects2.length = 0;
gdjs.LevelCode.GDspaceObjects3.length = 0;
gdjs.LevelCode.GDspaceObjects4.length = 0;
gdjs.LevelCode.GDspaceObjects5.length = 0;
gdjs.LevelCode.GDspaceObjects6.length = 0;
gdjs.LevelCode.GDlogosObjects1.length = 0;
gdjs.LevelCode.GDlogosObjects2.length = 0;
gdjs.LevelCode.GDlogosObjects3.length = 0;
gdjs.LevelCode.GDlogosObjects4.length = 0;
gdjs.LevelCode.GDlogosObjects5.length = 0;
gdjs.LevelCode.GDlogosObjects6.length = 0;
gdjs.LevelCode.GDselllllsObjects1.length = 0;
gdjs.LevelCode.GDselllllsObjects2.length = 0;
gdjs.LevelCode.GDselllllsObjects3.length = 0;
gdjs.LevelCode.GDselllllsObjects4.length = 0;
gdjs.LevelCode.GDselllllsObjects5.length = 0;
gdjs.LevelCode.GDselllllsObjects6.length = 0;

gdjs.LevelCode.eventsList28(runtimeScene);
return;

}

gdjs['LevelCode'] = gdjs.LevelCode;
